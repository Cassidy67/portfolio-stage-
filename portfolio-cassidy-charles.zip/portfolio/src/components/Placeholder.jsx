import { ImageIcon } from 'lucide-react'

/** Emplacement élégant affiché tant qu'aucune photo n'a été ajoutée. */
export default function Placeholder({ label = 'Photo à venir', className = '', tone = 'sand' }) {
  const bg = tone === 'blush' ? 'bg-blush/60' : 'bg-sand'
  return (
    <div
      role="img"
      aria-label={label}
      className={`relative flex h-full w-full flex-col items-center justify-center gap-3 overflow-hidden ${bg} text-taupe-deep ${className}`}
    >
      <svg aria-hidden className="absolute inset-0 h-full w-full opacity-50" viewBox="0 0 400 500" preserveAspectRatio="none">
        <path d="M-20 380 C 80 300, 160 440, 260 360 S 380 300, 430 340 L 430 520 L -20 520 Z" fill="#DCC9BA" opacity=".55" />
        <circle cx="320" cy="110" r="70" fill="#F8F5F0" opacity=".5" />
      </svg>
      <ImageIcon aria-hidden className="relative h-7 w-7" strokeWidth={1.25} />
      <span className="relative text-xs uppercase tracking-[0.2em]">{label}</span>
    </div>
  )
}
