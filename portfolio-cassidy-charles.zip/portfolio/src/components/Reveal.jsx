import { motion, useReducedMotion } from 'motion/react'

/** Apparition douce au défilement. Désactivée si l'utilisateur préfère moins d'animations. */
export default function Reveal({ children, delay = 0, y = 24, className = '', as = 'div', once = true }) {
  const reduce = useReducedMotion()
  const Tag = motion[as] || motion.div
  if (reduce) return <Tag className={className}>{children}</Tag>
  return (
    <Tag
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once, margin: '0px 0px -80px 0px' }}
      transition={{ duration: 0.8, delay, ease: [0.22, 0.61, 0.36, 1] }}
    >
      {children}
    </Tag>
  )
}
