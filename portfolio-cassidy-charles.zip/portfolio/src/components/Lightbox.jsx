import { useEffect, useRef } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { ChevronLeft, ChevronRight, X } from 'lucide-react'

/** Visionneuse plein écran : flèches clavier, Échap, balayage tactile. */
export default function Lightbox({ images, index, onClose, onChange }) {
  const open = index !== null && index !== undefined
  const closeRef = useRef(null)
  const touchX = useRef(null)
  const count = images.length

  useEffect(() => {
    if (!open) return
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    closeRef.current?.focus()
    const onKey = (e) => {
      if (e.key === 'Escape') onClose()
      if (e.key === 'ArrowRight') onChange((index + 1) % count)
      if (e.key === 'ArrowLeft') onChange((index - 1 + count) % count)
    }
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = prev
      window.removeEventListener('keydown', onKey)
    }
  }, [open, index, count, onClose, onChange])

  const img = open ? images[index] : null

  return (
    <AnimatePresence>
      {open && img && (
        <motion.div
          role="dialog"
          aria-modal="true"
          aria-label="Visionneuse d’images"
          className="fixed inset-0 z-[100] flex items-center justify-center bg-cocoa/95 p-4 sm:p-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          onClick={onClose}
          onTouchStart={(e) => (touchX.current = e.touches[0].clientX)}
          onTouchEnd={(e) => {
            if (touchX.current == null || count < 2) return
            const dx = e.changedTouches[0].clientX - touchX.current
            if (Math.abs(dx) > 50) onChange(dx < 0 ? (index + 1) % count : (index - 1 + count) % count)
            touchX.current = null
          }}
        >
          <button
            ref={closeRef}
            onClick={onClose}
            aria-label="Fermer"
            className="absolute right-4 top-4 rounded-full bg-ivory/10 p-3 text-ivory transition hover:bg-ivory/20 sm:right-8 sm:top-8"
          >
            <X className="h-5 w-5" />
          </button>

          {count > 1 && (
            <>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  onChange((index - 1 + count) % count)
                }}
                aria-label="Image précédente"
                className="absolute left-3 rounded-full bg-ivory/10 p-3 text-ivory transition hover:bg-ivory/20 sm:left-8"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  onChange((index + 1) % count)
                }}
                aria-label="Image suivante"
                className="absolute right-3 rounded-full bg-ivory/10 p-3 text-ivory transition hover:bg-ivory/20 sm:right-8"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </>
          )}

          <motion.figure
            key={img.url}
            className="flex max-h-full max-w-5xl flex-col items-center"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
            onClick={(e) => e.stopPropagation()}
          >
            <img src={img.url} alt={img.alt || ''} className="max-h-[80vh] w-auto rounded-xl object-contain" />
            <figcaption className="mt-4 text-center text-sm text-sand">
              {img.kind && <span className="uppercase tracking-[0.18em] text-blush">{img.kind}</span>}
              {img.alt && <span className="block pt-1">{img.alt}</span>}
              {count > 1 && (
                <span className="block pt-1 text-xs text-blush/80">
                  {index + 1} / {count}
                </span>
              )}
            </figcaption>
          </motion.figure>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
