import { Globe, Megaphone, Palette } from 'lucide-react'
import { useData } from '../../context/DataContext'
import SectionHead from '../ui/SectionHead'
import Reveal from '../ui/Reveal'
import { SKILL_CATEGORIES } from '../../lib/defaults'

const ICONS = { design: Palette, marketing: Megaphone, web: Globe }

export default function Skills() {
  const { content, skills } = useData()
  const visible = skills.filter((s) => s.visible !== false)
  const groups = SKILL_CATEGORIES.map((c) => ({ ...c, items: visible.filter((s) => s.category === c.key) })).filter((g) => g.items.length)
  if (!groups.length) return null

  return (
    <section id="competences" className="section bg-sand">
      <div className="container-x">
        <SectionHead index="03" eyebrow="Savoir-faire" title={content.skills.title} />
        <div className="grid gap-6 lg:grid-cols-3">
          {groups.map((g, i) => {
            const Icon = ICONS[g.key]
            return (
              <Reveal key={g.key} delay={i * 0.12} className={`group rounded-[1.75rem] border border-cocoa/10 bg-cream p-8 shadow-card transition-transform duration-500 hover:-translate-y-1.5 sm:p-10 ${i === 1 ? 'lg:mt-10' : ''}`}>
                <span className="flex h-14 w-14 items-center justify-center rounded-full bg-blush/70 text-cocoa transition-colors group-hover:bg-cocoa group-hover:text-cream">
                  <Icon className="h-6 w-6" strokeWidth={1.4} />
                </span>
                <h3 className="mt-8 text-[1.75rem] leading-tight">{g.title}</h3>
                <p className="mt-1 text-sm text-taupe-deep">{g.hint}</p>
                <div className="hairline my-7" />
                <ul className="flex flex-wrap gap-2.5">
                  {g.items.map((s) => (
                    <li key={s.id} className="chip !px-4 !py-2 !text-[0.82rem]">{s.label}</li>
                  ))}
                </ul>
              </Reveal>
            )
          })}
        </div>
      </div>
    </section>
  )
}
