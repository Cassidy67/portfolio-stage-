import { useEffect, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { Menu, X } from 'lucide-react'
import { useData } from '../../context/DataContext'
import { useGoTo } from './useGoTo'
import { cn } from '../../lib/utils'

export default function Navbar() {
  const { content } = useData()
  const { pathname } = useLocation()
  const goTo = useGoTo()
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState('accueil')

  const links = [
    { id: 'accueil', label: 'Accueil' },
    { id: 'a-propos', label: 'À propos' },
    { id: 'projets', label: 'Projets' },
    { id: 'competences', label: 'Compétences' },
    { id: 'logiciels', label: 'Logiciels' },
    { id: 'recherche', label: 'Stage' },
    { id: 'contact', label: 'Contact' },
  ]

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  // Indicateur de section active
  useEffect(() => {
    if (pathname !== '/') return
    const obs = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: '-45% 0px -50% 0px' },
    )
    const t = setTimeout(() => links.forEach((l) => { const el = document.getElementById(l.id); el && obs.observe(el) }), 400)
    return () => { clearTimeout(t); obs.disconnect() }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname])

  useEffect(() => setOpen(false), [pathname])

  const go = (id) => (e) => {
    e.preventDefault()
    setOpen(false)
    goTo(id)
  }

  const [first, ...rest] = (content.hero.name || '').split(' ')
  return (
    <header
      className={cn(
        'fixed inset-x-0 top-0 z-50 transition-all duration-500',
        scrolled || open ? 'bg-cream/85 shadow-[0_1px_0_rgba(73,55,47,.08)] backdrop-blur-md' : 'bg-transparent',
      )}
    >
      <nav aria-label="Navigation principale" className="container-x flex h-16 items-center justify-between">
        <a href="/" onClick={go('accueil')} className="font-display text-xl tracking-tight text-cocoa" aria-label="Retour à l'accueil">
          {first} <span className="italic">{rest.join(' ')}</span>
        </a>

        <ul className="hidden items-center gap-7 lg:flex">
          {links.map((l) => (
            <li key={l.id}>
              <a
                href={`#${l.id}`}
                onClick={go(l.id)}
                aria-current={pathname === '/' && active === l.id ? 'true' : undefined}
                className={cn(
                  'relative py-2 text-[0.82rem] tracking-wide transition-colors',
                  pathname === '/' && active === l.id ? 'text-cocoa' : 'text-taupe-deep hover:text-cocoa',
                )}
              >
                {l.label}
                <span
                  aria-hidden
                  className={cn(
                    'absolute inset-x-0 -bottom-0.5 h-px origin-left bg-cocoa transition-transform duration-500',
                    pathname === '/' && active === l.id ? 'scale-x-100' : 'scale-x-0',
                  )}
                />
              </a>
            </li>
          ))}
        </ul>

        <button
          className="-mr-2 rounded-full p-3 text-cocoa lg:hidden"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          aria-controls="menu-mobile"
          aria-label={open ? 'Fermer le menu' : 'Ouvrir le menu'}
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            id="menu-mobile"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden lg:hidden"
          >
            <ul className="container-x flex flex-col pb-6 pt-2">
              {links.map((l, i) => (
                <li key={l.id} className="border-t border-cocoa/10">
                  <a href={`#${l.id}`} onClick={go(l.id)} className="flex items-center justify-between py-4 font-display text-2xl text-cocoa">
                    {l.label}
                    <span className="text-xs text-taupe-deep">{String(i + 1).padStart(2, '0')}</span>
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  )
}
