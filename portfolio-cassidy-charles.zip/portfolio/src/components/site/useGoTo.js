import { useCallback } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'

// Navigation vers une section de la page d'accueil, depuis n'importe quelle page.
export function useGoTo() {
  const navigate = useNavigate()
  const { pathname } = useLocation()
  return useCallback(
    (id) => {
      if (pathname === '/') {
        document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
      } else {
        navigate('/', { state: { scrollTo: id } })
      }
    },
    [navigate, pathname],
  )
}
