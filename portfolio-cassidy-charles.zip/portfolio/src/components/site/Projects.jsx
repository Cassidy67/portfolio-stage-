import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowUpRight } from 'lucide-react'
import { useData } from '../../context/DataContext'
import SectionHead from '../ui/SectionHead'
import Placeholder from '../ui/Placeholder'
import Reveal from '../ui/Reveal'
import { PROJECT_CATEGORIES } from '../../lib/defaults'
import { cn } from '../../lib/utils'

export function ProjectCard({ p, index = 0, placeholder = false }) {
  const inner = (
    <>
      <div className="relative aspect-[4/3] overflow-hidden rounded-[1.5rem] bg-sand">
        <div className="h-full w-full transition-transform duration-[900ms] ease-out group-hover:scale-[1.05]">
          {p.cover_url ? (
            <img src={p.cover_url} alt={p.cover_alt || p.title} loading="lazy" className="h-full w-full object-cover" />
          ) : (
            <Placeholder label={placeholder ? 'Emplacement projet' : 'Visuel à venir'} tone={index % 2 ? 'blush' : 'sand'} />
          )}
        </div>
        <span className="absolute left-4 top-4 rounded-full bg-cream/90 px-3.5 py-1.5 text-[0.7rem] font-medium uppercase tracking-[0.16em] text-cocoa backdrop-blur">
          {p.category || 'Catégorie'}
        </span>
        <span aria-hidden className="absolute bottom-4 right-4 flex h-11 w-11 translate-y-2 items-center justify-center rounded-full bg-cocoa text-cream opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
          <ArrowUpRight className="h-5 w-5" />
        </span>
      </div>
      <div className="px-1 pt-6">
        <h3 className="text-[1.9rem] leading-tight">{p.title}</h3>
        <p className="mt-2 max-w-md leading-relaxed text-taupe-deep">{p.short_description}</p>
        {p.tools?.length > 0 && (
          <ul className="mt-4 flex flex-wrap gap-2" aria-label="Outils utilisés">
            {p.tools.map((t) => (
              <li key={t} className="chip">{t}</li>
            ))}
          </ul>
        )}
        <span className="mt-6 inline-flex items-center gap-2 border-b border-cocoa/40 pb-1 text-sm font-medium transition-all group-hover:gap-3 group-hover:border-cocoa">
          Découvrir le projet <ArrowUpRight className="h-4 w-4" />
        </span>
      </div>
    </>
  )
  return (
    <Link to={`/projets/${p.slug}`} className="group block">
      {inner}
    </Link>
  )
}

const PLACEHOLDERS = [0, 1, 2, 3, 4, 5].map((i) => ({
  id: 'ph' + i,
  slug: 'exemple',
  title: 'Projet à venir',
  category: PROJECT_CATEGORIES[i % PROJECT_CATEGORIES.length],
  short_description: 'Un emplacement prêt à accueillir un de tes projets, avec sa couverture, sa description et ses outils.',
  tools: [],
}))

export default function Projects() {
  const { content, projects, isLive } = useData()
  const [filter, setFilter] = useState('Tous')
  const published = useMemo(() => projects.filter((p) => p.status === 'published'), [projects])
  const preview = !isLive && published.length === 0
  const list = preview ? PLACEHOLDERS : published
  const shown = filter === 'Tous' ? list : list.filter((p) => p.category === filter)
  const filters = ['Tous', ...PROJECT_CATEGORIES]

  return (
    <section id="projets" className="section bg-cream">
      <div className="container-x">
        <SectionHead index="02" eyebrow="Réalisations" title={content.projects.title} intro={content.projects.intro} />

        <Reveal className="mb-14 flex flex-wrap gap-2.5" role="group" aria-label="Filtrer les projets par catégorie">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              aria-pressed={filter === f}
              className={cn(
                'rounded-full border px-5 py-2.5 text-sm transition-all duration-300',
                filter === f ? 'border-cocoa bg-cocoa text-cream' : 'border-cocoa/25 text-taupe-deep hover:border-cocoa hover:text-cocoa',
              )}
            >
              {f}
            </button>
          ))}
        </Reveal>

        {preview && (
          <p className="mb-10 rounded-2xl border border-dashed border-cocoa/25 bg-sand/50 px-5 py-4 text-sm text-taupe-deep">
            <strong className="font-medium text-cocoa">Aperçu :</strong> ces six emplacements sont des exemples. Seuls les projets que tu publies depuis l'administration s'affichent sur le site en ligne.
          </p>
        )}

        {list.length === 0 ? (
          <p className="rounded-3xl border border-cocoa/10 bg-sand/50 px-8 py-20 text-center font-display text-3xl italic text-taupe-deep">
            Mes premiers projets arrivent très bientôt.
          </p>
        ) : (
          <motion.ul layout className="grid gap-x-12 gap-y-16 md:grid-cols-2">
            <AnimatePresence mode="popLayout">
              {shown.map((p, i) => (
                <motion.li
                  layout
                  key={p.id}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-6% 0px' }}
                  exit={{ opacity: 0, scale: 0.97 }}
                  transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                  className={i % 2 === 1 ? 'md:mt-20' : ''}
                >
                  <ProjectCard p={p} index={i} placeholder={preview} />
                </motion.li>
              ))}
            </AnimatePresence>
          </motion.ul>
        )}
        {list.length > 0 && shown.length === 0 && (
          <p className="py-16 text-center font-display text-2xl italic text-taupe-deep">Aucun projet dans cette catégorie pour le moment.</p>
        )}
      </div>
    </section>
  )
}
