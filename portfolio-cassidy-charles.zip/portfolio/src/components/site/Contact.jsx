import { useRef, useState } from 'react'
import { ArrowUpRight, Mail, MapPin, Send } from 'lucide-react'
import { useData } from '../../context/DataContext'
import Reveal from '../ui/Reveal'
import SectionHead from '../ui/SectionHead'

const ENDPOINT = import.meta.env.VITE_FORM_ENDPOINT // ex. https://formspree.io/f/xxxx

export default function Contact() {
  const { content } = useData()
  const c = content.contact
  const [status, setStatus] = useState('idle') // idle | sending | ok | error
  const [err, setErr] = useState('')
  const openedAt = useRef(Date.now())

  const submit = async (e) => {
    e.preventDefault()
    const form = e.currentTarget
    const data = Object.fromEntries(new FormData(form))
    // Anti-spam : champ piège (honeypot) + délai minimal de saisie
    if (data._gotcha || Date.now() - openedAt.current < 3000) return setStatus('ok')
    setStatus('sending')
    setErr('')
    try {
      const res = await fetch(ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ name: data.name, email: data.email, subject: data.subject, message: data.message, _subject: `Portfolio — ${data.subject}` }),
      })
      if (!res.ok) throw new Error()
      setStatus('ok')
      form.reset()
    } catch {
      setStatus('error')
      setErr(`Le message n'a pas pu être envoyé. Écris-moi directement à ${c.email}.`)
    }
  }

  return (
    <section id="contact" className="section bg-cream">
      <div className="container-x grid gap-16 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <SectionHead index="06" eyebrow="Contact" title={c.title} intro={c.text} className="!mb-10" />
          <Reveal className="space-y-5">
            <a href={`mailto:${c.email}`} className="group flex items-center gap-4 text-lg">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-blush/60"><Mail className="h-5 w-5" strokeWidth={1.4} /></span>
              <span className="border-b border-transparent break-all group-hover:border-cocoa">{c.email}</span>
            </a>
            <a href={c.linkedin} target="_blank" rel="noopener noreferrer" className="group flex items-center gap-4 text-lg">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-blush/60 font-display text-xl italic">in</span>
              <span className="inline-flex items-center gap-1.5 border-b border-transparent group-hover:border-cocoa">LinkedIn <ArrowUpRight className="h-4 w-4" /></span>
            </a>
            <p className="flex items-center gap-4 text-lg">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-blush/60"><MapPin className="h-5 w-5" strokeWidth={1.4} /></span>
              {c.location}
            </p>
            <a href={`mailto:${c.email}?subject=${encodeURIComponent('Prise de contact — Portfolio')}`} className="btn-ghost mt-4">
              M'envoyer un e-mail
            </a>
          </Reveal>
        </div>

        <Reveal delay={0.15} className="lg:col-span-7">
          <form onSubmit={submit} className="rounded-[1.75rem] border border-cocoa/10 bg-sand/60 p-7 sm:p-10" noValidate={false}>
            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label htmlFor="c-name" className="label">Nom</label>
                <input id="c-name" name="name" required autoComplete="name" className="input" />
              </div>
              <div>
                <label htmlFor="c-email" className="label">Adresse e-mail</label>
                <input id="c-email" name="email" type="email" required autoComplete="email" className="input" />
              </div>
            </div>
            <div className="mt-5">
              <label htmlFor="c-subject" className="label">Objet</label>
              <input id="c-subject" name="subject" required className="input" />
            </div>
            <div className="mt-5">
              <label htmlFor="c-message" className="label">Message</label>
              <textarea id="c-message" name="message" required rows={6} className="input resize-y" />
            </div>
            {/* champ piège anti-spam, invisible pour les humains */}
            <div aria-hidden className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
              <label>Ne pas remplir<input name="_gotcha" tabIndex={-1} autoComplete="off" /></label>
            </div>

            <div className="mt-7 flex flex-wrap items-center gap-5">
              <button type="submit" disabled={!ENDPOINT || status === 'sending'} className="btn-primary">
                {status === 'sending' ? 'Envoi…' : 'Envoyer'} <Send className="h-4 w-4" />
              </button>
              <div role="status" aria-live="polite" className="text-sm">
                {!ENDPOINT && (
                  <span className="text-taupe-deep">Formulaire pas encore relié à un service d'envoi — utilise le bouton « M'envoyer un e-mail ».</span>
                )}
                {status === 'ok' && <span className="text-cocoa">Merci ! Ton message a bien été envoyé.</span>}
                {status === 'error' && <span className="text-[#8a3a2e]">{err}</span>}
              </div>
            </div>
          </form>
        </Reveal>
      </div>
    </section>
  )
}
