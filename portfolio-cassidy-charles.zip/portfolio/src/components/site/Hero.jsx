import { motion } from 'framer-motion'
import { ArrowDownRight, MapPin } from 'lucide-react'
import { useData } from '../../context/DataContext'
import { useGoTo } from './useGoTo'
import Placeholder from '../ui/Placeholder'
import { splitName } from '../../lib/utils'

const ease = [0.22, 1, 0.36, 1]
const up = (d = 0) => ({ initial: { opacity: 0, y: 28 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.9, delay: d, ease } })

function Blob({ className = '', fill = '#EDE3D6' }) {
  return (
    <svg aria-hidden viewBox="0 0 600 600" className={className}>
      <path
        fill={fill}
        d="M421.5 95.6c63.7 37.6 117.4 99.2 126.8 167.2 9.4 68-25.5 142.3-79.7 190.5-54.2 48.2-127.7 70.3-195.5 62.7-67.8-7.6-129.9-45-170.4-100.3C61.2 360.4 42.2 287.5 66.6 224.9 91 162.3 158.9 110 226.8 79.9c67.9-30.1 131-21.9 194.7 15.7Z"
      />
    </svg>
  )
}

export default function Hero() {
  const { content } = useData()
  const goTo = useGoTo()
  const h = content.hero
  const s = content.seeking
  const [first, last] = splitName(h.name)
  const initials = (first[0] || '') + (last[0] || '')

  return (
    <section id="accueil" className="relative flex min-h-[100svh] items-center overflow-hidden pb-20 pt-28 lg:pb-16">
      {/* décor organique */}
      <Blob className="pointer-events-none absolute -right-[22%] top-[6%] h-[80vh] w-[80vh] max-w-none opacity-80 sm:-right-[12%] lg:-right-[6%]" />
      <Blob fill="#DCC9BA" className="pointer-events-none absolute -left-[18%] bottom-[-18%] h-[46vh] w-[46vh] max-w-none rotate-90 opacity-30" />

      <div className="container-x relative grid items-center gap-14 lg:grid-cols-12 lg:gap-8">
        <div className="lg:col-span-7">
          <motion.p {...up(0.1)} className="eyebrow mb-7">
            <span aria-hidden className="h-px w-10 bg-cocoa/30" />
            Portfolio 2026
          </motion.p>

          <h1 className="leading-[0.88] tracking-tight text-[clamp(3.8rem,11.5vw,9.5rem)]">
            <motion.span {...up(0.2)} className="block">{first}</motion.span>
            <motion.span {...up(0.32)} className="block pl-[0.5em] italic text-cocoa/90">{last}</motion.span>
          </h1>

          <motion.p {...up(0.5)} className="mt-8 font-sans text-[0.8rem] font-medium uppercase tracking-[0.28em] text-taupe-deep sm:text-sm">
            {h.subtitle}
          </motion.p>

          <motion.p {...up(0.6)} className="mt-6 max-w-md font-display text-2xl italic leading-snug text-cocoa sm:text-[1.7rem]">
            « {h.tagline} »
          </motion.p>

          <motion.p {...up(0.7)} className="mt-6 inline-flex items-center gap-2 rounded-full border border-cocoa/20 bg-cream/70 px-4 py-2 text-sm text-taupe-deep backdrop-blur">
            <span aria-hidden className="h-1.5 w-1.5 rounded-full bg-cocoa" />
            {h.status}
          </motion.p>

          <motion.p {...up(0.75)} className="mt-3 flex flex-wrap items-center gap-x-2 text-sm text-taupe-deep">
            <MapPin aria-hidden className="h-4 w-4" /> Stage recherché : <strong className="font-medium text-cocoa">{s.location}</strong> · {s.period}
          </motion.p>

          <motion.div {...up(0.8)} className="mt-10 flex flex-wrap gap-4">
            <button onClick={() => goTo('projets')} className="btn-primary">
              Découvrir mes projets <ArrowDownRight className="h-4 w-4" />
            </button>
            <button onClick={() => goTo('contact')} className="btn-ghost">Me contacter</button>
          </motion.div>
        </div>

        {/* portrait */}
        <motion.div {...up(0.35)} className="relative mx-auto w-full max-w-[420px] lg:col-span-5 lg:max-w-none lg:justify-self-end">
          <div aria-hidden className="absolute inset-0 translate-x-4 translate-y-4 rounded-t-[999px] rounded-b-[1.75rem] border border-cocoa/30 sm:translate-x-6 sm:translate-y-6" />
          <div className="relative aspect-[4/5] overflow-hidden rounded-t-[999px] rounded-b-[1.75rem] bg-blush shadow-soft">
            {h.portrait ? (
              <img src={h.portrait} alt={h.portraitAlt || h.name} className="h-full w-full object-cover" fetchpriority="high" />
            ) : (
              <Placeholder initials={initials} label="Ta photo portrait ici" tone="blush" icon={false} />
            )}
          </div>
          <div className="absolute -left-3 bottom-10 rounded-2xl border border-cocoa/10 bg-cream/95 px-5 py-3 shadow-card backdrop-blur sm:-left-10">
            <p className="font-display text-lg italic leading-tight">Ynov Campus</p>
            <p className="text-xs uppercase tracking-[0.18em] text-taupe-deep">Strasbourg · B2</p>
          </div>
        </motion.div>
      </div>

      <div className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-3 text-[0.65rem] uppercase tracking-[0.3em] text-taupe-deep [@media(min-height:720px)]:flex">
        Défiler
        <span aria-hidden className="scrollcue relative block h-10 w-px overflow-hidden bg-cocoa/20" />
      </div>
    </section>
  )
}
