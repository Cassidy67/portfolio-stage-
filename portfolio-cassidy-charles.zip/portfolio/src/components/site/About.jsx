import { useState } from 'react'
import { Download, Eye, FileText } from 'lucide-react'
import Lightbox from '../ui/Lightbox'
import { useData } from '../../context/DataContext'
import Reveal from '../ui/Reveal'
import Placeholder from '../ui/Placeholder'
import SectionHead from '../ui/SectionHead'

// Aperçu Claude uniquement : le navigateur de l'aperçu ne peut pas ouvrir de PDF, on affiche donc l'image du document.
const PREVIEW = import.meta.env.VITE_PREVIEW === 'true'
const PREVIEW_IMG = { cv: '/preview/cv.webp', letter: '/preview/lettre.webp' }

function DocButton({ href, icon: Icon, children, variant = 'btn-primary', download, soon, onPreview }) {
  if (PREVIEW && onPreview) {
    return (
      <button type="button" onClick={onPreview} className={variant}>
        <Icon className="h-4 w-4" /> {children}
      </button>
    )
  }
  if (!href) {
    return soon ? (
      <span aria-disabled="true" title="Document pas encore ajouté" className={`${variant} !cursor-not-allowed opacity-45`}>
        <Icon className="h-4 w-4" /> {children}
      </span>
    ) : null
  }
  return (
    <a href={href} target={download ? undefined : '_blank'} rel="noopener noreferrer" download={download ? 'CV-Cassidy-Charles.pdf' : undefined} className={variant}>
      <Icon className="h-4 w-4" /> {children}
    </a>
  )
}

export default function About() {
  const { content, isLive } = useData()
  const a = content.about
  const d = content.documents
  const soon = !isLive // en aperçu, on montre les boutons même sans fichier
  const [view, setView] = useState(null)
  const imgs = [{ url: PREVIEW_IMG.cv, alt: 'CV de Cassidy Charles' }, { url: PREVIEW_IMG.letter, alt: 'Lettre de motivation de Cassidy Charles' }]
  return (
    <section id="a-propos" className="section bg-cream">
      <div className="container-x grid items-center gap-14 lg:grid-cols-12 lg:gap-20">
        <Reveal className="relative lg:col-span-5">
          <div aria-hidden className="absolute -bottom-5 -left-5 h-2/3 w-2/3 rounded-3xl bg-blush/70 sm:-bottom-7 sm:-left-7" />
          <div className="relative aspect-[4/5] overflow-hidden rounded-[1.75rem] bg-sand shadow-soft">
            {a.photo ? (
              <img src={a.photo} alt={a.photoAlt || ''} loading="lazy" className="h-full w-full object-cover" />
            ) : (
              <Placeholder label="Ta photo personnelle ici" />
            )}
          </div>
        </Reveal>

        <div className="lg:col-span-7">
          <SectionHead index="01" eyebrow="À propos" title={a.title} className="!mb-8 sm:!mb-10" />
          <Reveal delay={0.1} className="max-w-xl space-y-5 text-[1.05rem] leading-[1.8] text-taupe-deep">
            {a.paragraphs.filter(Boolean).map((p, i) => (
              <p key={i} className={i === 0 ? 'text-lg text-cocoa' : ''}>{p}</p>
            ))}
          </Reveal>
          {a.qualities?.length > 0 && (
            <Reveal delay={0.15} as="ul" className="mt-8 flex flex-wrap gap-2.5" aria-label="En quelques mots">
              {a.qualities.map((q) => <li key={q} className="chip !px-4 !py-2 !text-[0.82rem] !text-cocoa">{q}</li>)}
            </Reveal>
          )}
          <Reveal delay={0.2} className="mt-10 flex flex-wrap gap-3">
            <DocButton href={d.cv} icon={Eye} soon={soon} onPreview={() => setView(0)}>Voir mon CV</DocButton>
            <DocButton href={d.letter} icon={FileText} variant="btn-ghost" soon={soon} onPreview={() => setView(1)}>Voir ma lettre de motivation</DocButton>
            {!PREVIEW && <DocButton href={d.cv} icon={Download} variant="btn-soft" download soon={soon}>Télécharger mon CV</DocButton>}
          </Reveal>
        </div>
      </div>
      <Lightbox images={imgs} index={view} onClose={() => setView(null)} onIndex={setView} />
    </section>
  )
}
