import { Link } from 'react-router-dom'
import { Lock } from 'lucide-react'
import { useData } from '../../context/DataContext'

export default function Footer() {
  const { content } = useData()
  return (
    <footer className="border-t border-cocoa/10 bg-cream">
      <div className="container-x flex flex-col items-start justify-between gap-5 py-10 text-sm text-taupe-deep sm:flex-row sm:items-center">
        <p>
          © {new Date().getFullYear()} <span className="font-display text-base italic text-cocoa">{content.hero.name}</span> — Tous droits réservés
        </p>
        <div className="flex items-center gap-6">
          <Link to="/mentions-legales" className="hover:text-cocoa">Mentions légales</Link>
          <Link to="/admin" aria-label="Espace d'administration" className="inline-flex items-center gap-1.5 hover:text-cocoa">
            <Lock className="h-3.5 w-3.5" /> Admin
          </Link>
        </div>
      </div>
    </footer>
  )
}
