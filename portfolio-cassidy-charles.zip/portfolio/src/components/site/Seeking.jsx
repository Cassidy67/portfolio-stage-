import { Briefcase, CalendarDays, Clock, MapPin } from 'lucide-react'
import { useData } from '../../context/DataContext'
import { useGoTo } from './useGoTo'
import Reveal from '../ui/Reveal'
import SectionHead from '../ui/SectionHead'

export default function Seeking() {
  const { content } = useData()
  const goTo = useGoTo()
  const s = content.seeking
  const blocks = [
    { icon: Briefcase, label: 'Domaines', value: s.domains },
    { icon: CalendarDays, label: 'Période', value: s.period },
    { icon: Clock, label: 'Durée', value: s.duration },
    { icon: MapPin, label: 'Localisation', value: s.location },
  ]
  return (
    <section id="recherche" className="section bg-sand-deep">
      <div className="container-x">
        <div className="grid items-end gap-10 lg:grid-cols-12">
          <SectionHead index="05" eyebrow="Ce que je recherche" title={s.title} intro={s.text} className="lg:col-span-8 !mb-0" />
          <Reveal className="lg:col-span-4 lg:justify-self-end">
            <button onClick={() => goTo('contact')} className="btn-primary">Échangeons !</button>
          </Reveal>
        </div>
        <div className="mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {blocks.map(({ icon: Icon, label, value }, i) => (
            <Reveal key={label} delay={i * 0.08} className="rounded-3xl bg-cream/75 p-7 backdrop-blur">
              <Icon className="h-6 w-6 text-taupe" strokeWidth={1.3} />
              <p className="mt-6 text-[0.72rem] font-medium uppercase tracking-[0.22em] text-taupe-deep">{label}</p>
              <p className="mt-2 font-display text-[1.6rem] leading-snug">{value}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
