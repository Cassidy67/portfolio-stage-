import { useData } from '../../context/DataContext'
import SectionHead from '../ui/SectionHead'
import Reveal from '../ui/Reveal'
import { TOOLS, TOOL_GROUPS } from '../../lib/tools'

function Logo({ t }) {
  return t.logo ? (
    <img src={t.logo} alt="" loading="lazy" className="h-10 w-10 object-contain" />
  ) : (
    <span aria-hidden className="flex h-10 w-10 items-center justify-center rounded-xl bg-cocoa font-display text-xl italic leading-none text-cream">{t.mono}</span>
  )
}

export default function Tools() {
  const { content } = useData()
  const c = content.tools
  const hidden = new Set(c.hidden || [])
  const groups = TOOL_GROUPS.map((g) => ({ ...g, items: TOOLS.filter((t) => t.group === g.key && !hidden.has(t.key)) })).filter((g) => g.items.length)
  if (!groups.length) return null

  return (
    <section id="logiciels" className="section bg-cream">
      <div className="container-x">
        <SectionHead index="04" eyebrow="Boîte à outils" title={c.title} intro={c.intro} />
        <div className="divide-y divide-cocoa/10 border-y border-cocoa/10">
          {groups.map((g, gi) => (
            <Reveal key={g.key} delay={gi * 0.05} className="grid gap-6 py-10 lg:grid-cols-12 lg:gap-10">
              <div className="lg:col-span-3">
                <h3 className="text-[1.7rem] leading-tight">{g.title}</h3>
                <p className="mt-1 text-sm text-taupe-deep">{g.hint}</p>
              </div>
              <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:col-span-9 lg:grid-cols-4">
                {g.items.map((t) => (
                  <li key={t.key} className="group flex items-center gap-3.5 rounded-2xl border border-cocoa/10 bg-sand/50 px-4 py-3.5 transition duration-300 hover:-translate-y-1 hover:bg-sand hover:shadow-card">
                    <Logo t={t} />
                    <span className="text-[0.92rem] font-medium leading-tight">{t.name}</span>
                  </li>
                ))}
              </ul>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
