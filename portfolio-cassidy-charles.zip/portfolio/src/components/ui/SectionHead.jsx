import Reveal from './Reveal'
import { cn } from '../../lib/utils'

export default function SectionHead({ index, eyebrow, title, intro, className = '', align = 'left' }) {
  return (
    <Reveal className={cn('mb-14 max-w-3xl sm:mb-20', align === 'center' && 'mx-auto text-center', className)}>
      <p className={cn('eyebrow mb-6', align === 'center' && 'justify-center')}>
        <span className="font-display text-base normal-case tracking-normal italic">{index}</span>
        <span aria-hidden className="h-px w-10 bg-cocoa/30" />
        {eyebrow}
      </p>
      <h2 className="text-[clamp(2.4rem,5.5vw,4.4rem)] leading-[1.02] tracking-tight">{title}</h2>
      {intro && <p className="mt-6 max-w-2xl text-lg leading-relaxed text-taupe-deep">{intro}</p>}
    </Reveal>
  )
}
