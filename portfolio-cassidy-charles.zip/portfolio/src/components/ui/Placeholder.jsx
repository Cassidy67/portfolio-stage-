import { Image as ImageIcon } from 'lucide-react'
import { cn } from '../../lib/utils'

// Emplacement élégant pour une photo pas encore fournie.
export default function Placeholder({ label = 'Photo à venir', initials, className = '', tone = 'sand', icon = true }) {
  const bg = tone === 'blush' ? 'bg-blush/70' : tone === 'cream' ? 'bg-cream' : 'bg-sand'
  return (
    <div
      role="img"
      aria-label={label}
      className={cn('relative flex h-full w-full flex-col items-center justify-center gap-2 overflow-hidden text-taupe-deep', bg, className)}
    >
      <svg aria-hidden className="absolute inset-0 h-full w-full opacity-[0.55]" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="ph-lines" width="22" height="22" patternUnits="userSpaceOnUse" patternTransform="rotate(35)">
            <line x1="0" y1="0" x2="0" y2="22" stroke="#DCC9BA" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#ph-lines)" />
      </svg>
      {initials ? (
        <span className="relative font-display text-6xl italic text-cocoa/70 sm:text-7xl">{initials}</span>
      ) : (
        icon && <ImageIcon aria-hidden className="relative h-7 w-7 opacity-60" strokeWidth={1.25} />
      )}
      <span className="relative text-[0.7rem] font-medium uppercase tracking-[0.2em]">{label}</span>
    </div>
  )
}
