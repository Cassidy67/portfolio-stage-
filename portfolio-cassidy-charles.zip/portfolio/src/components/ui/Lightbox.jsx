import { useEffect, useRef } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ChevronLeft, ChevronRight, X } from 'lucide-react'

// Visionneuse plein écran : clavier (Échap, ←, →), clic en dehors pour fermer.
export default function Lightbox({ images, index, onClose, onIndex }) {
  const open = index !== null && index !== undefined
  const closeRef = useRef(null)
  const count = images.length

  useEffect(() => {
    if (!open) return
    const prevFocus = document.activeElement
    closeRef.current?.focus()
    const onKey = (e) => {
      if (e.key === 'Escape') onClose()
      if (e.key === 'ArrowRight') onIndex((index + 1) % count)
      if (e.key === 'ArrowLeft') onIndex((index - 1 + count) % count)
    }
    document.addEventListener('keydown', onKey)
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = prev
      prevFocus?.focus?.()
    }
  }, [open, index, count, onClose, onIndex])

  const img = open ? images[index] : null
  return (
    <AnimatePresence>
      {open && img && (
        <motion.div
          role="dialog"
          aria-modal="true"
          aria-label="Visionneuse d'images"
          className="fixed inset-0 z-[100] flex items-center justify-center bg-cocoa/90 p-4 backdrop-blur-sm sm:p-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <button ref={closeRef} onClick={onClose} aria-label="Fermer" className="absolute right-4 top-4 rounded-full bg-cream/10 p-3 text-cream transition hover:bg-cream/20 sm:right-8 sm:top-8">
            <X className="h-5 w-5" />
          </button>
          {count > 1 && (
            <>
              <button
                onClick={(e) => { e.stopPropagation(); onIndex((index - 1 + count) % count) }}
                aria-label="Image précédente"
                className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-cream/10 p-3 text-cream transition hover:bg-cream/20 sm:left-8"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); onIndex((index + 1) % count) }}
                aria-label="Image suivante"
                className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-cream/10 p-3 text-cream transition hover:bg-cream/20 sm:right-8"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </>
          )}
          <motion.figure
            key={img.url}
            className="flex max-h-full max-w-full flex-col items-center"
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.35 }}
            onClick={(e) => e.stopPropagation()}
          >
            <img src={img.url} alt={img.alt || ''} className="max-h-[80vh] max-w-full rounded-lg object-contain shadow-2xl" />
            {(img.caption || count > 1) && (
              <figcaption className="mt-4 text-center text-sm text-cream/80">
                {img.caption}
                {count > 1 && <span className="ml-3 text-cream/50">{index + 1} / {count}</span>}
              </figcaption>
            )}
          </motion.figure>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
