import { lazy, Suspense, useEffect } from 'react'
import { BrowserRouter, HashRouter, Outlet, Route, Routes, useLocation } from 'react-router-dom'
import { MotionConfig } from 'framer-motion'
import { DataProvider } from './context/DataContext'
import { AuthProvider } from './context/AuthContext'
import Navbar from './components/site/Navbar'
import Footer from './components/site/Footer'
import BackToTop from './components/site/BackToTop'
import Home from './pages/Home'
import ProjectPage from './pages/ProjectPage'
import Legal from './pages/Legal'
import NotFound from './pages/NotFound'

const Admin = lazy(() => import('./admin/AdminApp'))
const Router = import.meta.env.VITE_HASH_ROUTER === 'true' ? HashRouter : BrowserRouter

function SiteLayout() {
  const { pathname, state } = useLocation()
  useEffect(() => {
    if (!state?.scrollTo) window.scrollTo(0, 0)
  }, [pathname, state])
  return (
    <>
      <a href="#contenu" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[200] focus:rounded-full focus:bg-cocoa focus:px-5 focus:py-3 focus:text-cream">
        Aller au contenu
      </a>
      <Navbar />
      <div id="contenu"><Outlet /></div>
      <Footer />
      <BackToTop />
    </>
  )
}

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <Router>
        <AuthProvider>
          <DataProvider>
            <Routes>
              <Route element={<SiteLayout />}>
                <Route path="/" element={<Home />} />
                <Route path="/projets/:slug" element={<ProjectPage />} />
                <Route path="/mentions-legales" element={<Legal />} />
                <Route path="*" element={<NotFound />} />
              </Route>
              <Route
                path="/admin/*"
                element={
                  <Suspense fallback={<div className="p-10 text-taupe-deep">Chargement…</div>}>
                    <Admin />
                  </Suspense>
                }
              />
            </Routes>
          </DataProvider>
        </AuthProvider>
      </Router>
    </MotionConfig>
  )
}
