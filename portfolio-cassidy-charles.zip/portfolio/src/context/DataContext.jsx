import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { api } from '../lib/api'
import { isConfigured } from '../lib/supabase'
import { DEFAULT_CONTENT } from '../lib/defaults'
import { SEED_PROJECTS } from '../lib/seed'

const Ctx = createContext(null)
export const useData = () => useContext(Ctx)

export function DataProvider({ children }) {
  const [state, setState] = useState({ content: DEFAULT_CONTENT, projects: [], skills: [], certs: [], media: [] })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const refresh = useCallback(async () => {
    try {
      const data = await api.loadAll()
      setState(data)
      setError(null)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    refresh()
  }, [refresh])

  const run = useCallback(
    async (fn) => {
      const res = await fn()
      await refresh()
      return res
    },
    [refresh],
  )

  const actions = useMemo(
    () => ({
      saveContent: (content) => run(() => api.saveContent(content)),
      upsert: (table, row) => run(() => api.upsert(table, row)),
      remove: (table, id) => run(() => api.remove(table, id)),
      saveOrder: (table, ids) => run(() => api.saveOrder(table, ids)),
      uploadMedia: (blob, meta) => run(() => api.uploadMedia(blob, meta)),
      updateMedia: (id, patch) => run(() => api.updateMedia(id, patch)),
      deleteMedia: (item) => run(() => api.deleteMedia(item)),
      // Remplace un fichier puis met à jour toutes les références (projets, textes, certifications…)
      replaceMedia: (id, blob, current) =>
        run(async () => {
          const { oldUrl, newUrl } = await api.replaceMedia(id, blob, current)
          const swap = (obj) => JSON.parse(JSON.stringify(obj).split(oldUrl).join(newUrl))
          if (JSON.stringify(state.content).includes(oldUrl)) await api.saveContent(swap(state.content))
          for (const p of state.projects) if (JSON.stringify(p).includes(oldUrl)) await api.upsert('projects', swap(p))
          for (const c of state.certs) if (JSON.stringify(c).includes(oldUrl)) await api.upsert('certifications', swap(c))
          return newUrl
        }),
    }),
    [run, state],
  )

  // Où une image est-elle utilisée ? (bibliothèque de médias)
  const usageOf = useCallback(
    (url) => {
      const used = []
      const has = (o) => JSON.stringify(o || '').includes(url)
      const c = state.content
      if (has(c.hero)) used.push('Accueil')
      if (has(c.about)) used.push('À propos')
      if (has(c.documents)) used.push('Documents')
      if (has(c.process)) used.push('Démarche')
      state.projects.filter(has).forEach((p) => used.push(`Projet : ${p.title}`))
      state.certs.filter(has).forEach((x) => used.push(`Certification : ${x.name}`))
      return used
    },
    [state],
  )

  // Tant que la base Supabase ne contient aucun projet, le site public affiche les projets intégrés au code.
  const usingSeed = isConfigured && state.projects.length === 0
  const importSeed = () => run(async () => { for (const p of SEED_PROJECTS) await api.upsert('projects', p) })
  const value = {
    ...state,
    projects: usingSeed ? SEED_PROJECTS : state.projects, // vue publique
    adminProjects: state.projects, // contenu réel de la base (administration)
    usingSeed,
    importSeed,
    loading, error, refresh, isLive: isConfigured, usageOf, ...actions,
  }
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}
