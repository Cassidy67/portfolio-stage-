import { createContext, useContext, useEffect, useState } from 'react'
import { supabase, isConfigured } from '../lib/supabase'

const Ctx = createContext(null)
export const useAuth = () => useContext(Ctx)

export function AuthProvider({ children }) {
  const [session, setSession] = useState(null)
  const [demo, setDemo] = useState(false) // mode démo : uniquement quand Supabase n'est pas configuré
  const [ready, setReady] = useState(!isConfigured)

  useEffect(() => {
    if (!isConfigured) return
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session)
      setReady(true)
    })
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s))
    return () => sub.subscription.unsubscribe()
  }, [])

  const signIn = async (email, password) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) throw new Error(error.message === 'Invalid login credentials' ? 'E-mail ou mot de passe incorrect.' : error.message)
  }
  const signOut = async () => {
    if (isConfigured) await supabase.auth.signOut()
    setDemo(false)
  }

  const user = isConfigured ? session?.user : demo ? { email: 'démo' } : null
  return <Ctx.Provider value={{ user, ready, demo, startDemo: () => setDemo(true), signIn, signOut }}>{children}</Ctx.Provider>
}
