import { createContext, useContext, useEffect, useMemo, useState, useCallback } from 'react'
import { isConfigured } from '../lib/supabase'
import { loadPublicContent } from '../lib/api'
import { DEFAULT_SETTINGS, DEFAULT_SKILLS, SKILL_CATEGORIES } from '../lib/defaults'
import { mergeSettings } from '../lib/format'

const ContentContext = createContext(null)

export function ContentProvider({ children }) {
  const [state, setState] = useState({
    loading: isConfigured,
    error: null,
    settings: {},
    projects: [],
    skills: [],
    certifications: [],
  })

  const load = useCallback(async () => {
    if (!isConfigured) return
    try {
      const data = await loadPublicContent()
      setState({ loading: false, error: null, ...data })
    } catch (e) {
      console.error(e)
      setState((s) => ({ ...s, loading: false, error: e }))
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  const value = useMemo(() => {
    const settings = mergeSettings(DEFAULT_SETTINGS, state.settings)

    // Compétences : base de données si configurée et renseignée, sinon liste par défaut du cahier des charges.
    const fromDb = state.skills.length > 0
    const skills = SKILL_CATEGORIES.map((cat) => ({
      ...cat,
      items: fromDb
        ? state.skills.filter((s) => s.category === cat.key).map((s) => s.label)
        : DEFAULT_SKILLS[cat.key],
    })).filter((c) => c.items.length > 0)

    return {
      ...state,
      configured: isConfigured,
      settings,
      skills,
      reload: load,
    }
  }, [state, load])

  return <ContentContext.Provider value={value}>{children}</ContentContext.Provider>
}

export const useContent = () => useContext(ContentContext)
