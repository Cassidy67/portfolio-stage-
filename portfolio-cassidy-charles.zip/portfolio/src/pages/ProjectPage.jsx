import { useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { ArrowLeft, ArrowRight } from 'lucide-react'
import { useData } from '../context/DataContext'
import { useMeta } from '../lib/useMeta'
import { EXAMPLE_PROJECT } from '../lib/defaults'
import Reveal from '../components/ui/Reveal'
import Placeholder from '../components/ui/Placeholder'
import Lightbox from '../components/ui/Lightbox'
import NotFound from './NotFound'

function Block({ index, title, children }) {
  return (
    <Reveal className="grid gap-6 border-t border-cocoa/15 py-12 md:grid-cols-12 md:gap-10 md:py-16">
      <div className="md:col-span-4">
        <p className="font-display text-lg italic text-taupe">{index}</p>
        <h2 className="mt-1 text-4xl">{title}</h2>
      </div>
      <div className="space-y-8 md:col-span-8">{children}</div>
    </Reveal>
  )
}

const Text = ({ label, value }) =>
  value ? (
    <div>
      {label && <h3 className="mb-2 font-sans text-[0.72rem] font-medium uppercase tracking-[0.22em] text-taupe-deep">{label}</h3>}
      <p className="whitespace-pre-line text-[1.05rem] leading-[1.85] text-cocoa/90">{value}</p>
    </div>
  ) : null

export default function ProjectPage() {
  const { slug } = useParams()
  const { projects, loading, isLive } = useData()
  const [lb, setLb] = useState(null)

  const published = projects.filter((p) => p.status === 'published')
  const p = slug === 'exemple' && !isLive ? EXAMPLE_PROJECT : published.find((x) => x.slug === slug)

  useMeta(p ? `${p.title} — Cassidy Charles` : 'Projet introuvable', p?.short_description)
  if (loading) return <div className="min-h-screen" />
  if (!p) return <NotFound />

  const idx = published.findIndex((x) => x.id === p.id)
  const next = published.length > 1 && idx >= 0 ? published[(idx + 1) % published.length] : null
  const gallery = (p.gallery || []).filter((g) => g.url)
  const hasPresentation = p.context || p.objectives || p.project_type
  const n = (() => { let i = 0; return () => String(++i).padStart(2, '0') })()

  return (
    <main className="pb-24 pt-28 sm:pt-36">
      <div className="container-x">
        <Link to="/" state={{ scrollTo: 'projets' }} className="inline-flex items-center gap-2 text-sm text-taupe-deep transition hover:-translate-x-1 hover:text-cocoa">
          <ArrowLeft className="h-4 w-4" /> Retour aux projets
        </Link>

        {p.isExample && (
          <p className="mt-6 rounded-2xl border border-dashed border-cocoa/25 bg-sand/50 px-5 py-4 text-sm text-taupe-deep">
            <strong className="font-medium text-cocoa">Page modèle :</strong> voici la mise en page d'une page projet. Les textes sont des consignes, pas un vrai projet. Les rubriques vides n'apparaissent pas sur le site en ligne.
          </p>
        )}

        <header className="mt-10 max-w-4xl">
          <p className="eyebrow mb-5">
            <span aria-hidden className="h-px w-10 bg-cocoa/30" /> {p.category}
            {p.project_type && <span className="rounded-full border border-cocoa/20 px-3 py-0.5 normal-case tracking-normal">{p.project_type}</span>}
          </p>
          <h1 className="text-[clamp(2.8rem,8vw,6.5rem)] leading-[0.95] tracking-tight">{p.title}</h1>
          {p.short_description && <p className="mt-6 max-w-2xl font-display text-2xl italic leading-snug text-taupe-deep">{p.short_description}</p>}
        </header>

        <Reveal className="mt-12 aspect-[16/10] overflow-hidden rounded-[1.75rem] bg-sand shadow-soft sm:mt-16">
          {p.cover_url ? (
            <img src={p.cover_url} alt={p.cover_alt || p.title} className="h-full w-full object-cover" fetchpriority="high" />
          ) : (
            <Placeholder label="Image de couverture" />
          )}
        </Reveal>

        <div className="mt-16">
          {hasPresentation && (
            <Block index={n()} title="Présentation">
              <Text label="Contexte" value={p.context} />
              <Text label="Objectifs" value={p.objectives} />
              {p.project_type && <Text label="Type de projet" value={p.project_type} />}
            </Block>
          )}
          {p.role && (
            <Block index={n()} title="Mon rôle">
              <Text value={p.role} />
            </Block>
          )}
          {p.process && (
            <Block index={n()} title="Démarche">
              <Text value={p.process} />
            </Block>
          )}
          {p.tools?.length > 0 && (
            <Block index={n()} title="Outils">
              <ul className="flex flex-wrap gap-3">
                {p.tools.map((t) => <li key={t} className="chip !px-5 !py-2.5 !text-sm">{t}</li>)}
              </ul>
            </Block>
          )}
          {(p.result || p.learnings || p.isExample) && (
            <Block index={n()} title="Résultat">
              <Text value={p.result} />
              <Text label="Ce que j'ai appris" value={p.learnings} />
            </Block>
          )}
        </div>

        {(gallery.length > 0 || p.isExample) && (
          <section aria-label="Galerie du projet" className="mt-4">
            <div className="grid grid-cols-1 items-start gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {(gallery.length ? gallery : [1, 2, 3, 4].map((i) => ({ ph: i }))).map((g, i) =>
                g.ph ? (
                  <div key={i} className={`overflow-hidden rounded-2xl ${i % 2 ? 'aspect-[3/4]' : 'aspect-[4/3]'}`}>
                    <Placeholder label="Visuel du projet" tone={i % 2 ? 'blush' : 'sand'} />
                  </div>
                ) : (
                  <Reveal key={g.url + i} y={16} className="break-inside-avoid">
                    <button onClick={() => setLb(i)} className="group block w-full overflow-hidden rounded-2xl bg-sand" aria-label={`Agrandir l'image ${i + 1}`}>
                      <img src={g.url} alt={g.alt || `${p.title} — visuel ${i + 1}`} loading="lazy" className="w-full transition-transform duration-700 group-hover:scale-[1.04]" />
                    </button>
                  </Reveal>
                ),
              )}
            </div>
          </section>
        )}

        <div className="mt-20 flex flex-wrap items-center justify-between gap-6 border-t border-cocoa/15 pt-10">
          <Link to="/" state={{ scrollTo: 'projets' }} className="btn-ghost"><ArrowLeft className="h-4 w-4" /> Retour à la galerie</Link>
          {next && (
            <Link to={`/projets/${next.slug}`} className="group text-right">
              <span className="text-xs uppercase tracking-[0.2em] text-taupe-deep">Projet suivant</span>
              <span className="mt-1 flex items-center justify-end gap-3 font-display text-3xl">
                {next.title} <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" />
              </span>
            </Link>
          )}
        </div>
      </div>
      <Lightbox images={gallery} index={lb} onClose={() => setLb(null)} onIndex={setLb} />
    </main>
  )
}
