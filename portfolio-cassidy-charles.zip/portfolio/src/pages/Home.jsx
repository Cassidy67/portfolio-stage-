import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import Hero from '../components/site/Hero'
import About from '../components/site/About'
import Projects from '../components/site/Projects'
import Skills from '../components/site/Skills'
import Tools from '../components/site/Tools'
import Seeking from '../components/site/Seeking'
import Contact from '../components/site/Contact'
import { useMeta } from '../lib/useMeta'
import { useData } from '../context/DataContext'

export default function Home() {
  const { state } = useLocation()
  const { content } = useData()
  useMeta(
    `${content.hero.name} — Portfolio Marketing, Communication & Design`,
    `Portfolio de ${content.hero.name}, ${content.hero.status.toLowerCase()} à Ynov Campus Strasbourg. À la recherche d'un stage (${content.seeking.period}).`,
  )

  useEffect(() => {
    if (state?.scrollTo) {
      const t = setTimeout(() => document.getElementById(state.scrollTo)?.scrollIntoView({ behavior: 'smooth' }), 120)
      return () => clearTimeout(t)
    }
  }, [state])

  return (
    <main>
      <Hero />
      <About />
      <Projects />
      <Skills />
      <Tools />
      <Seeking />
      <Contact />
    </main>
  )
}
