import { Link } from 'react-router-dom'
import { useMeta } from '../lib/useMeta'

export default function NotFound() {
  useMeta('Page introuvable — Cassidy Charles', 'Cette page n\'existe pas.')
  return (
    <main className="flex min-h-[80vh] items-center">
      <div className="container-x text-center">
        <p className="font-display text-[clamp(7rem,24vw,16rem)] italic leading-none text-blush">404</p>
        <h1 className="mt-2 text-4xl sm:text-5xl">Cette page s'est égarée.</h1>
        <p className="mx-auto mt-4 max-w-md text-taupe-deep">Le lien est peut-être erroné, ou le projet a été retiré. Retournons à l'essentiel.</p>
        <Link to="/" className="btn-primary mt-9">Retour à l'accueil</Link>
      </div>
    </main>
  )
}
