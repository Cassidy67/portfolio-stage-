import { Link } from 'react-router-dom'
import { useData } from '../context/DataContext'
import { useMeta } from '../lib/useMeta'

const H = ({ children }) => <h2 className="mb-3 mt-12 text-3xl">{children}</h2>

export default function Legal() {
  const { content } = useData()
  const { name } = content.hero
  const { email } = content.contact
  const { host, hostAddress } = content.legal
  useMeta('Mentions légales — Cassidy Charles', 'Mentions légales et politique de confidentialité du portfolio de Cassidy Charles.')

  return (
    <main className="pb-24 pt-32 sm:pt-40">
      <div className="container-x max-w-3xl">
        <Link to="/" className="text-sm text-taupe-deep hover:text-cocoa">← Retour à l'accueil</Link>
        <h1 className="mt-8 text-[clamp(2.8rem,7vw,5rem)] leading-none">Mentions légales</h1>
        <div className="mt-6 space-y-4 leading-relaxed text-taupe-deep [&_strong]:font-medium [&_strong]:text-cocoa">
          <H>Éditrice du site</H>
          <p><strong>{name}</strong>, personne physique, étudiante.<br />Site personnel à but non commercial (portfolio étudiant).<br />Contact : <a className="underline" href={`mailto:${email}`}>{email}</a></p>
          <p>Directrice de la publication : {name}.</p>

          <H>Hébergement</H>
          {host ? (
            <p>Ce site est hébergé par <strong>{host}</strong>{hostAddress ? <>, {hostAddress}</> : null}.</p>
          ) : (
            <p className="rounded-xl border border-dashed border-cocoa/30 bg-sand/50 p-4 text-sm">
              <strong>À compléter :</strong> indique le nom et l'adresse de l'hébergeur choisi (Netlify, Vercel, OVH…) depuis l'administration, rubrique « Coordonnées ».
            </p>
          )}
          <p>Les données et fichiers du site sont stockés via le service Supabase.</p>

          <H>Propriété intellectuelle</H>
          <p>L'ensemble des contenus de ce site (textes, visuels, projets, logos, photographies) est la propriété de {name}, sauf mention contraire. Toute reproduction, représentation ou réutilisation sans autorisation écrite préalable est interdite. Les marques et logos tiers cités appartiennent à leurs propriétaires respectifs.</p>

          <H>Données personnelles</H>
          <p>Lorsque vous utilisez le formulaire de contact, les informations saisies (nom, adresse e-mail, objet, message) sont utilisées uniquement pour vous répondre. Elles ne sont ni vendues, ni cédées à des tiers, et sont conservées le temps nécessaire au traitement de votre demande.</p>
          <p>Conformément au RGPD et à la loi « Informatique et Libertés », vous disposez d'un droit d'accès, de rectification et de suppression de vos données : écrivez à <a className="underline" href={`mailto:${email}`}>{email}</a>. Vous pouvez aussi introduire une réclamation auprès de la CNIL (cnil.fr).</p>

          <H>Cookies</H>
          <p>Ce site n'utilise aucun cookie publicitaire ni outil de mesure d'audience. Seule l'espace d'administration, réservé à l'éditrice, utilise un stockage technique pour maintenir la session de connexion.</p>

          <H>Responsabilité</H>
          <p>Les liens vers des sites externes (LinkedIn, etc.) sont fournis à titre indicatif ; {name} ne saurait être tenue responsable de leur contenu.</p>
        </div>
      </div>
    </main>
  )
}
