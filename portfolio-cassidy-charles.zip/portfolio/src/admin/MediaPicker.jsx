import { useRef, useState } from 'react'
import { Check, Loader2, Upload } from 'lucide-react'
import { Modal, useToast } from './ui'
import { useData } from '../context/DataContext'
import { ACCEPT_IMG, uploadImages } from './upload'
import { cn } from '../lib/utils'

// Choisir une ou plusieurs images déjà importées (ou en importer de nouvelles).
export default function MediaPicker({ open, onClose, onPick, multiple = false }) {
  const { media, uploadMedia } = useData()
  const toast = useToast()
  const [sel, setSel] = useState([])
  const [busy, setBusy] = useState(false)
  const input = useRef(null)
  const images = media.filter((m) => m.kind === 'image')

  const toggle = (m) => setSel((s) => (multiple ? (s.find((x) => x.id === m.id) ? s.filter((x) => x.id !== m.id) : [...s, m]) : [m]))
  const upload = async (files) => {
    setBusy(true)
    const rows = await uploadImages(files, uploadMedia, toast)
    setBusy(false)
    if (rows.length) setSel((s) => (multiple ? [...s, ...rows] : [rows[0]]))
  }
  const confirm = () => { onPick(multiple ? sel : sel[0]); setSel([]); onClose() }

  return (
    <Modal open={open} onClose={() => { setSel([]); onClose() }} title="Bibliothèque de photos" wide>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-taupe-deep">{images.length} photo{images.length > 1 ? 's' : ''} · clique pour sélectionner{multiple ? ' (plusieurs possibles)' : ''}</p>
        <button onClick={() => input.current.click()} disabled={busy} className="btn-soft !py-2.5">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} Importer des photos
        </button>
        <input ref={input} type="file" accept={ACCEPT_IMG} multiple hidden onChange={(e) => { upload(e.target.files); e.target.value = '' }} />
      </div>

      {images.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-cocoa/25 py-16 text-center text-taupe-deep">Aucune photo pour le moment. Importe tes premières photos ci-dessus.</p>
      ) : (
        <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
          {images.map((m) => {
            const on = sel.some((x) => x.id === m.id)
            return (
              <li key={m.id}>
                <button onClick={() => toggle(m)} aria-pressed={on} className={cn('relative block aspect-square w-full overflow-hidden rounded-xl bg-sand ring-offset-2 transition', on ? 'ring-2 ring-cocoa' : 'hover:opacity-90')}>
                  <img src={m.url} alt={m.alt || m.name} className="h-full w-full object-cover" loading="lazy" />
                  {on && <span className="absolute right-2 top-2 flex h-6 w-6 items-center justify-center rounded-full bg-cocoa text-cream"><Check className="h-4 w-4" /></span>}
                </button>
                <p className="mt-1 truncate text-xs text-taupe-deep">{m.name}</p>
              </li>
            )
          })}
        </ul>
      )}
      <div className="sticky bottom-0 -mx-6 -mb-6 mt-6 flex justify-end gap-3 border-t border-cocoa/10 bg-cream px-6 py-4">
        <button onClick={() => { setSel([]); onClose() }} className="btn-ghost !py-2.5">Annuler</button>
        <button onClick={confirm} disabled={!sel.length} className="btn-primary !py-2.5">Utiliser {sel.length > 1 ? `${sel.length} photos` : 'cette photo'}</button>
      </div>
    </Modal>
  )
}
