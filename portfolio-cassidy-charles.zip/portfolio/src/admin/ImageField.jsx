import { useRef, useState } from 'react'
import { FolderOpen, Loader2, Trash2, Upload } from 'lucide-react'
import { useData } from '../context/DataContext'
import { useToast } from './ui'
import MediaPicker from './MediaPicker'
import Cropper from './Cropper'
import { ACCEPT_IMG, MAX_MB } from './upload'
import { optimizeImage, PRESETS } from '../lib/images'
import { cn } from '../lib/utils'

// Champ image : importer (avec recadrage), choisir dans la bibliothèque, retirer, texte alternatif.
export default function ImageField({ label, value, alt, onChange, preset = 'cover', crop = true, withAlt = true, hint }) {
  const { uploadMedia } = useData()
  const toast = useToast()
  const [picker, setPicker] = useState(false)
  const [file, setFile] = useState(null)
  const [busy, setBusy] = useState(false)
  const input = useRef(null)
  const aspect = PRESETS[preset]?.aspect || 4 / 3

  const send = async (blob, name) => {
    setBusy(true)
    try {
      const row = await uploadMedia(blob, { name, kind: 'image' })
      onChange({ url: row.url, alt: alt || row.alt || '' })
    } catch (e) {
      toast(e.message, 'error')
    }
    setBusy(false)
  }

  const onFile = async (f) => {
    if (!f) return
    if (!f.type.startsWith('image/')) return toast("Ce fichier n'est pas une image.", 'error')
    if (f.size > MAX_MB * 1024 * 1024) return toast(`Image trop lourde (max ${MAX_MB} Mo).`, 'error')
    if (crop && !/svg|gif/.test(f.type)) setFile(f)
    else send(await optimizeImage(f), f.name)
  }

  return (
    <div>
      <span className="label">{label}</span>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start">
        <div
          className={cn('relative w-full shrink-0 overflow-hidden rounded-xl border border-dashed border-cocoa/30 bg-sand/60 sm:w-48')}
          style={{ aspectRatio: aspect }}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => { e.preventDefault(); onFile(e.dataTransfer.files?.[0]) }}
        >
          {value ? <img src={value} alt={alt || ''} className="h-full w-full object-cover" /> : (
            <button type="button" onClick={() => input.current.click()} className="flex h-full w-full flex-col items-center justify-center gap-1 p-3 text-center text-xs text-taupe-deep">
              <Upload className="h-5 w-5" /> Glisse une photo ici ou clique
            </button>
          )}
          {busy && <div className="absolute inset-0 flex items-center justify-center bg-cream/70"><Loader2 className="h-6 w-6 animate-spin" /></div>}
        </div>
        <div className="flex-1 space-y-3">
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={() => input.current.click()} className="btn-soft !px-4 !py-2 !text-[0.8rem]"><Upload className="h-4 w-4" /> {value ? 'Remplacer' : 'Importer'}</button>
            <button type="button" onClick={() => setPicker(true)} className="btn-ghost !px-4 !py-2 !text-[0.8rem]"><FolderOpen className="h-4 w-4" /> Bibliothèque</button>
            {value && <button type="button" onClick={() => onChange({ url: '', alt: '' })} className="btn !px-4 !py-2 !text-[0.8rem] text-[#8a3a2e] hover:bg-[#8a3a2e]/10"><Trash2 className="h-4 w-4" /> Retirer</button>}
          </div>
          {withAlt && value && (
            <div>
              <label className="mb-1 block text-xs text-taupe-deep">Description de l'image (accessibilité &amp; référencement)</label>
              <input value={alt || ''} onChange={(e) => onChange({ url: value, alt: e.target.value })} placeholder="Ex. : Affiche du projet sur fond beige" className="input !py-2 text-sm" />
            </div>
          )}
          {hint && <p className="text-xs text-taupe-deep">{hint}</p>}
        </div>
      </div>
      <input ref={input} type="file" accept={ACCEPT_IMG} hidden onChange={(e) => { onFile(e.target.files?.[0]); e.target.value = '' }} />
      <MediaPicker open={picker} onClose={() => setPicker(false)} onPick={(m) => onChange({ url: m.url, alt: m.alt || alt || '' })} />
      {file && <Cropper source={file} initialPreset={preset} onCancel={() => setFile(null)} onDone={(blob) => { const f = file; setFile(null); send(blob, f.name) }} />}
    </div>
  )
}
