import { optimizeImage } from '../lib/images'

export const ACCEPT_IMG = 'image/png,image/jpeg,image/webp,image/gif,image/svg+xml,image/heic'
export const MAX_MB = 25

/** Optimise et envoie une liste de fichiers image ; retourne les enregistrements médias créés. */
export async function uploadImages(files, uploadMedia, toast) {
  const out = []
  for (const f of Array.from(files)) {
    if (!f.type.startsWith('image/')) { toast(`« ${f.name} » n'est pas une image.`, 'error'); continue }
    if (f.size > MAX_MB * 1024 * 1024) { toast(`« ${f.name} » dépasse ${MAX_MB} Mo.`, 'error'); continue }
    try {
      const blob = await optimizeImage(f)
      out.push(await uploadMedia(blob, { name: f.name, kind: 'image' }))
    } catch (e) {
      toast(`Échec pour « ${f.name} » : ${e.message}`, 'error')
    }
  }
  return out
}
