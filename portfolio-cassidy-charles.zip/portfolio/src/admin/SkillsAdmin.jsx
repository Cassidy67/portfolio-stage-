import { useState } from 'react'
import { Eye, EyeOff, Plus, Trash2 } from 'lucide-react'
import { useData } from '../context/DataContext'
import { Card, IconBtn, PageHeader, SortableList, useToast } from './ui'
import { SKILL_CATEGORIES } from '../lib/defaults'
import { uid } from '../lib/utils'

function Column({ cat }) {
  const { skills, upsert, remove, saveOrder } = useData()
  const toast = useToast()
  const [draft, setDraft] = useState('')
  const items = skills.filter((s) => s.category === cat.key)

  const add = async (e) => {
    e.preventDefault()
    const label = draft.trim()
    if (!label) return
    try { await upsert('skills', { id: uid(), category: cat.key, label, visible: true, position: skills.length + 1 }); setDraft('') } catch (err) { toast(err.message, 'error') }
  }
  const run = (fn) => fn().catch((e) => toast(e.message, 'error'))

  return (
    <Card className="!p-5 sm:!p-6">
      <h2 className="text-2xl">{cat.title}</h2>
      <p className="mb-4 text-xs text-taupe-deep">{items.filter((s) => s.visible).length} affichée(s) sur le site</p>
      <SortableList items={items} className="space-y-1.5" onReorder={(n) => run(() => saveOrder('skills', n.map((s) => s.id)))}
        renderItem={(s, _i, { handle }) => (
          <div className="flex items-center gap-2 rounded-xl border border-cocoa/10 bg-cream px-2 py-1">
            {handle}
            <span className={`flex-1 text-sm ${s.visible ? '' : 'text-taupe line-through'}`}>{s.label}</span>
            <IconBtn label={s.visible ? 'Masquer sur le site' : 'Afficher sur le site'} onClick={() => run(() => upsert('skills', { id: s.id, visible: !s.visible }))}>{s.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}</IconBtn>
            <IconBtn label="Supprimer" danger onClick={() => confirm(`Retirer « ${s.label} » ?`) && run(() => remove('skills', s.id))}><Trash2 className="h-4 w-4" /></IconBtn>
          </div>
        )}
      />
      <form onSubmit={add} className="mt-4 flex gap-2">
        <input value={draft} onChange={(e) => setDraft(e.target.value)} aria-label={`Ajouter une compétence à ${cat.title}`} placeholder="Ajouter une compétence…" className="input !py-2.5 text-sm" />
        <button className="btn-soft !px-4 !py-2.5" aria-label="Ajouter"><Plus className="h-4 w-4" /></button>
      </form>
    </Card>
  )
}

export default function SkillsAdmin() {
  return (
    <>
      <PageHeader title="Compétences" intro="Ne garde que ce que tu maîtrises vraiment : masque ou supprime le reste. Aucun pourcentage de maîtrise n'est affiché sur le site." />
      <div className="grid gap-5 xl:grid-cols-3">
        {SKILL_CATEGORIES.map((c) => <Column key={c.key} cat={c} />)}
      </div>
    </>
  )
}
