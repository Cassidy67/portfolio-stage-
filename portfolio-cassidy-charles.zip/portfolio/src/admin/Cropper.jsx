import { useEffect, useMemo, useRef, useState } from 'react'
import { Check, Loader2 } from 'lucide-react'
import { Modal } from './ui'
import { cropImage, loadImage, PRESETS } from '../lib/images'
import { cn } from '../lib/utils'

// Recadrage : on déplace l'image avec le doigt/la souris et on zoome avec le curseur.
export default function Cropper({ source, initialPreset = 'cover', onCancel, onDone, title = 'Recadrer la photo' }) {
  const [img, setImg] = useState(null)
  const [preset, setPreset] = useState(initialPreset)
  const [zoom, setZoom] = useState(1)
  const [pos, setPos] = useState({ x: 0, y: 0 })
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const drag = useRef(null)

  useEffect(() => {
    let url, alive = true
    const src = typeof source === 'string' ? source : (url = URL.createObjectURL(source))
    loadImage(src).then((i) => alive && setImg(i)).catch((e) => alive && setError(e.message))
    return () => { alive = false; url && URL.revokeObjectURL(url) }
  }, [source])

  const aspect = useMemo(() => (preset === 'original' && img ? img.naturalWidth / img.naturalHeight : PRESETS[preset]?.aspect || 1), [preset, img])

  // Taille du cadre à l'écran
  const maxW = Math.min(520, (typeof window !== 'undefined' ? window.innerWidth : 600) - 80)
  const maxH = 400
  const fh = maxW / aspect > maxH ? maxH : maxW / aspect
  const fw = fh * aspect

  const base = img ? Math.max(fw / img.naturalWidth, fh / img.naturalHeight) : 1
  const s = base * zoom
  const clamp = (p) => img ? ({
    x: Math.min(0, Math.max(fw - img.naturalWidth * s, p.x)),
    y: Math.min(0, Math.max(fh - img.naturalHeight * s, p.y)),
  }) : p

  // Re-centre à chaque changement de format / zoom
  useEffect(() => {
    if (!img) return
    setPos((p) => clamp(p.x === 0 && p.y === 0 ? { x: (fw - img.naturalWidth * s) / 2, y: (fh - img.naturalHeight * s) / 2 } : p))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [img, preset, zoom])

  const onDown = (e) => { drag.current = { x: e.clientX, y: e.clientY, p: pos }; e.currentTarget.setPointerCapture(e.pointerId) }
  const onMove = (e) => { if (drag.current) setPos(clamp({ x: drag.current.p.x + e.clientX - drag.current.x, y: drag.current.p.y + e.clientY - drag.current.y })) }
  const onUp = () => { drag.current = null }

  const confirm = async () => {
    setBusy(true)
    try {
      const area = { sx: -pos.x / s, sy: -pos.y / s, sw: fw / s, sh: fh / s }
      const blob = await cropImage(img, area, PRESETS[preset]?.width || 1800)
      onDone(blob)
    } catch (e) {
      setError(e.message)
      setBusy(false)
    }
  }

  return (
    <Modal open onClose={onCancel} title={title}>
      {error ? <p className="text-[#8a3a2e]">{error}</p> : !img ? (
        <p className="flex items-center gap-2 text-taupe-deep"><Loader2 className="h-4 w-4 animate-spin" /> Chargement…</p>
      ) : (
        <div className="flex flex-col items-center gap-5">
          <div className="flex flex-wrap justify-center gap-2" role="group" aria-label="Format de recadrage">
            {Object.entries(PRESETS).map(([k, v]) => (
              <button key={k} onClick={() => { setPreset(k); setPos({ x: 0, y: 0 }) }} aria-pressed={preset === k} className={cn('rounded-full border px-4 py-1.5 text-sm', preset === k ? 'border-cocoa bg-cocoa text-cream' : 'border-cocoa/25')}>{v.label}</button>
            ))}
            <button onClick={() => { setPreset('original'); setPos({ x: 0, y: 0 }) }} aria-pressed={preset === 'original'} className={cn('rounded-full border px-4 py-1.5 text-sm', preset === 'original' ? 'border-cocoa bg-cocoa text-cream' : 'border-cocoa/25')}>Original</button>
          </div>

          <div
            className="relative cursor-move touch-none overflow-hidden rounded-xl bg-sand ring-1 ring-cocoa/20"
            style={{ width: fw, height: fh }}
            onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}
          >
            <img src={img.src} alt="Aperçu du recadrage" draggable={false} className="pointer-events-none absolute max-w-none select-none" style={{ width: img.naturalWidth * s, height: img.naturalHeight * s, left: pos.x, top: pos.y }} />
          </div>
          <p className="text-xs text-taupe-deep">Glisse l'image pour la déplacer · le cadre montre le résultat final</p>

          <label className="flex w-full max-w-sm items-center gap-4 text-sm">
            Zoom
            <input type="range" min="1" max="3" step="0.01" value={zoom} onChange={(e) => setZoom(+e.target.value)} className="flex-1 accent-[#49372F]" />
          </label>

          <div className="flex gap-3">
            <button onClick={onCancel} className="btn-ghost">Annuler</button>
            <button onClick={confirm} disabled={busy} className="btn-primary">{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />} Valider le recadrage</button>
          </div>
        </div>
      )}
    </Modal>
  )
}
