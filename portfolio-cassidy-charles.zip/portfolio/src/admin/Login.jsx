import { useState } from 'react'
import { Link } from 'react-router-dom'
import { AlertTriangle, Loader2, Lock } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { isConfigured } from '../lib/supabase'

export default function Login() {
  const { signIn, startDemo } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    setBusy(true); setErr('')
    try { await signIn(email, password) } catch (x) { setErr(x.message) }
    setBusy(false)
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-sand px-5 py-16">
      <div className="w-full max-w-md">
        <Link to="/" className="mb-8 block text-center text-sm text-taupe-deep hover:text-cocoa">← Retour au site</Link>
        <div className="rounded-[1.75rem] border border-cocoa/10 bg-cream p-8 shadow-soft sm:p-10">
          <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-blush/70"><Lock className="h-6 w-6" strokeWidth={1.4} /></span>
          <h1 className="mt-6 text-center text-4xl">Espace privé</h1>

          {isConfigured ? (
            <form onSubmit={submit} className="mt-8 space-y-5">
              <div><label htmlFor="l-mail" className="label">Adresse e-mail</label><input id="l-mail" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className="input" /></div>
              <div><label htmlFor="l-pw" className="label">Mot de passe</label><input id="l-pw" type="password" required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} className="input" /></div>
              {err && <p role="alert" className="text-sm text-[#8a3a2e]">{err}</p>}
              <button disabled={busy} className="btn-primary w-full">{busy && <Loader2 className="h-4 w-4 animate-spin" />} Se connecter</button>
            </form>
          ) : (
            <div className="mt-6 space-y-5 text-sm leading-relaxed text-taupe-deep">
              <p className="flex gap-3 rounded-2xl bg-[#f1ddc6] p-4 text-[#6b4217]"><AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" /> <span><strong>Supabase n'est pas encore configuré.</strong> La connexion sécurisée, l'enregistrement durable et l'envoi des photos ne sont donc pas actifs. Les étapes sont détaillées dans le fichier README du projet.</span></p>
              <p>En attendant, tu peux explorer l'interface en <strong className="text-cocoa">mode démonstration</strong> : tout fonctionne, mais <strong className="text-cocoa">rien n'est enregistré</strong> et tout disparaît au rechargement de la page.</p>
              <button onClick={startDemo} className="btn-primary w-full">Explorer l'administration (démo)</button>
            </div>
          )}
        </div>
      </div>
    </main>
  )
}
