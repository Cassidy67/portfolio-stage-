import { useEffect, useRef, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { ArrowLeft, FolderOpen, Loader2, Trash2, Upload } from 'lucide-react'
import { useData } from '../context/DataContext'
import { Card, Input, PageHeader, Select, SortableList, TagInput, useToast } from './ui'
import ImageField from './ImageField'
import MediaPicker from './MediaPicker'
import { ACCEPT_IMG, uploadImages } from './upload'
import { PROJECT_CATEGORIES, PROJECT_TYPES } from '../lib/defaults'
import { slugify, uid } from '../lib/utils'

const EMPTY = { title: '', category: '', project_type: '', short_description: '', context: '', objectives: '', role: '', process: '', tools: [], result: '', learnings: '', cover_url: '', cover_alt: '', gallery: [], status: 'draft' }

export default function ProjectForm() {
  const { id } = useParams()
  const { adminProjects: projects, upsert, uploadMedia, loading } = useData()
  const toast = useToast()
  const navigate = useNavigate()
  const existing = id ? projects.find((p) => p.id === id) : null
  const [p, setP] = useState(EMPTY)
  const [loaded, setLoaded] = useState(!id)
  const [saving, setSaving] = useState(false)
  const [picker, setPicker] = useState(false)
  const [upBusy, setUpBusy] = useState(false)
  const input = useRef(null)
  const set = (k) => (v) => setP((x) => ({ ...x, [k]: v }))

  useEffect(() => {
    if (id && existing && !loaded) { setP({ ...EMPTY, ...existing, gallery: existing.gallery || [], tools: existing.tools || [] }); setLoaded(true) }
  }, [id, existing, loaded])

  if (id && !existing && !loading) return <Card>Projet introuvable. <Link className="underline" to="/admin/projets">Retour à la liste</Link></Card>
  if (!loaded) return <p className="text-taupe-deep">Chargement…</p>

  const save = async (status) => {
    if (!p.title.trim()) return toast('Ajoute au moins un titre.', 'error')
    if (status === 'published' && (!p.category || !p.short_description.trim())) return toast('Pour publier, renseigne la catégorie et une courte description.', 'error')
    setSaving(true)
    try {
      let slug = p.slug
      if (!slug) {
        const base = slugify(p.title)
        slug = base
        let i = 2
        while (projects.some((x) => x.slug === slug)) slug = `${base}-${i++}`
      }
      const row = { ...p, slug, status, id: p.id || uid(), position: p.position ?? projects.length + 1 }
      const saved = await upsert('projects', row)
      toast(status === 'published' ? 'Projet publié ✓' : 'Brouillon enregistré')
      if (!id) navigate(`/admin/projets/${saved.id}`, { replace: true })
      else setP((x) => ({ ...x, status, slug }))
    } catch (e) { toast(e.message, 'error') }
    setSaving(false)
  }

  const addFiles = async (files) => {
    setUpBusy(true)
    const rows = await uploadImages(files, uploadMedia, toast)
    setUpBusy(false)
    if (rows.length) setP((x) => ({ ...x, gallery: [...x.gallery, ...rows.map((r) => ({ url: r.url, alt: r.alt || '', caption: '' }))] }))
  }
  const updGal = (i, patch) => setP((x) => ({ ...x, gallery: x.gallery.map((g, j) => (j === i ? { ...g, ...patch } : g)) }))

  return (
    <>
      <Link to="/admin/projets" className="mb-4 inline-flex items-center gap-2 text-sm text-taupe-deep hover:text-cocoa"><ArrowLeft className="h-4 w-4" /> Tous les projets</Link>
      <PageHeader title={id ? 'Modifier le projet' : 'Nouveau projet'} intro={p.status === 'published' ? 'Ce projet est publié sur le site.' : 'Ce projet est en brouillon : il n\'est pas visible sur le site.'} />

      <div className="space-y-6 pb-28">
        <Card className="space-y-5">
          <h2 className="text-2xl">Informations principales</h2>
          <Input label="Titre du projet *" value={p.title} onChange={set('title')} />
          <div className="grid gap-5 sm:grid-cols-2">
            <Select label="Catégorie" value={p.category} onChange={set('category')} options={PROJECT_CATEGORIES} hint="Sert aux filtres de la galerie." />
            <Select label="Type de projet" value={p.project_type} onChange={set('project_type')} options={PROJECT_TYPES} />
          </div>
          <Input label="Courte description" hint="Affichée sur la carte du projet (1 à 2 phrases)." textarea rows={2} value={p.short_description} onChange={set('short_description')} />
          <TagInput label="Outils utilisés" value={p.tools} onChange={set('tools')} hint="Logiciels et méthodes : Figma, Canva, Persona, benchmark…" />
          <ImageField label="Image de couverture" preset="cover" value={p.cover_url} alt={p.cover_alt} onChange={({ url, alt }) => setP((x) => ({ ...x, cover_url: url, cover_alt: alt }))} hint="Format 4:3 recommandé — tu peux recadrer à l'import." />
        </Card>

        <Card className="space-y-5">
          <h2 className="text-2xl">Présentation</h2>
          <Input label="Contexte" textarea rows={4} value={p.context} onChange={set('context')} hint="Pour qui, dans quel cadre, pourquoi ?" />
          <Input label="Objectifs" textarea rows={3} value={p.objectives} onChange={set('objectives')} />
        </Card>

        <Card className="space-y-5">
          <h2 className="text-2xl">Mon rôle &amp; ma démarche</h2>
          <Input label="Mon rôle" textarea rows={4} value={p.role} onChange={set('role')} hint="Missions réalisées, responsabilités." />
          <Input label="Démarche" textarea rows={5} value={p.process} onChange={set('process')} hint="Recherches, inspirations, moodboards, étapes de création." />
        </Card>

        <Card className="space-y-5">
          <h2 className="text-2xl">Résultat</h2>
          <Input label="Résultat" textarea rows={4} value={p.result} onChange={set('result')} />
          <Input label="Ce que j'ai appris" textarea rows={3} value={p.learnings} onChange={set('learnings')} hint="Compétences développées." />
        </Card>

        <Card>
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-2xl">Galerie d'images</h2>
              <p className="text-sm text-taupe-deep">Photos, maquettes, captures, moodboards, logos, supports… Glisse pour réorganiser.</p>
            </div>
            <div className="flex gap-2">
              <button type="button" onClick={() => input.current.click()} disabled={upBusy} className="btn-soft !py-2.5 !text-[0.8rem]">{upBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} Importer</button>
              <button type="button" onClick={() => setPicker(true)} className="btn-ghost !py-2.5 !text-[0.8rem]"><FolderOpen className="h-4 w-4" /> Bibliothèque</button>
            </div>
          </div>
          <input ref={input} type="file" accept={ACCEPT_IMG} multiple hidden onChange={(e) => { addFiles(e.target.files); e.target.value = '' }} />
          <MediaPicker multiple open={picker} onClose={() => setPicker(false)} onPick={(rows) => setP((x) => ({ ...x, gallery: [...x.gallery, ...rows.map((r) => ({ url: r.url, alt: r.alt || '', caption: '' }))] }))} />

          {p.gallery.length === 0 ? (
            <div onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); addFiles(e.dataTransfer.files) }} className="rounded-2xl border border-dashed border-cocoa/30 py-14 text-center text-sm text-taupe-deep">
              Glisse plusieurs images ici ou utilise « Importer ».
            </div>
          ) : (
            <SortableList
              items={p.gallery.map((g, i) => ({ ...g, _k: g.url + i }))}
              getKey={(g) => g._k}
              onReorder={(next) => setP((x) => ({ ...x, gallery: next.map(({ _k, ...g }) => g) }))}
              className="space-y-3"
              renderItem={(g, i, { handle, arrows }) => (
                <div className="flex items-start gap-3 rounded-2xl border border-cocoa/10 bg-cream p-3">
                  <div className="flex items-center gap-1 pt-6">{handle}{arrows}</div>
                  <img src={g.url} alt="" className="h-24 w-28 shrink-0 rounded-xl object-cover" />
                  <div className="grid min-w-0 flex-1 gap-2 sm:grid-cols-2">
                    <input aria-label="Description de l'image" value={g.alt || ''} onChange={(e) => updGal(i, { alt: e.target.value })} placeholder="Description (accessibilité)" className="input !py-2 text-sm" />
                    <input aria-label="Légende" value={g.caption || ''} onChange={(e) => updGal(i, { caption: e.target.value })} placeholder="Légende (optionnel)" className="input !py-2 text-sm" />
                    <div className="sm:col-span-2 flex gap-3 text-xs">
                      <button type="button" disabled={i === 0 && p.cover_url === g.url} onClick={() => setP((x) => ({ ...x, cover_url: g.url, cover_alt: g.alt || x.cover_alt }))} className="underline underline-offset-2 hover:text-cocoa">Utiliser comme couverture</button>
                    </div>
                  </div>
                  <button type="button" aria-label="Retirer de la galerie" onClick={() => setP((x) => ({ ...x, gallery: x.gallery.filter((_, j) => j !== i) }))} className="rounded-full p-2 text-[#8a3a2e] hover:bg-[#8a3a2e]/10"><Trash2 className="h-4 w-4" /></button>
                </div>
              )}
            />
          )}
        </Card>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-30 border-t border-cocoa/10 bg-cream/95 backdrop-blur lg:left-64">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-end gap-3 px-5 py-3.5">
          {saving && <Loader2 className="h-4 w-4 animate-spin text-taupe" />}
          <button onClick={() => save('draft')} disabled={saving} className="btn-ghost !py-2.5">Enregistrer comme brouillon</button>
          <button onClick={() => save('published')} disabled={saving} className="btn-primary !py-2.5">{p.status === 'published' ? 'Mettre à jour' : 'Publier le projet'}</button>
        </div>
      </div>
    </>
  )
}
