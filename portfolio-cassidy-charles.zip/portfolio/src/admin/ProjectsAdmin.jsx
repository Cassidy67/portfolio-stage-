import { Link, useNavigate } from 'react-router-dom'
import { Eye, EyeOff, ExternalLink, Pencil, Plus, Trash2 } from 'lucide-react'
import { useData } from '../context/DataContext'
import { Badge, Card, IconBtn, PageHeader, SortableList, useToast } from './ui'
import Placeholder from '../components/ui/Placeholder'

export default function ProjectsAdmin() {
  const { adminProjects: projects, usingSeed, importSeed, upsert, remove, saveOrder } = useData()
  const toast = useToast()
  const navigate = useNavigate()

  const toggle = async (p) => {
    try {
      await upsert('projects', { id: p.id, status: p.status === 'published' ? 'draft' : 'published' })
      toast(p.status === 'published' ? 'Projet masqué (brouillon)' : 'Projet publié')
    } catch (e) { toast(e.message, 'error') }
  }
  const del = async (p) => {
    if (!confirm(`Supprimer définitivement « ${p.title} » ?`)) return
    try { await remove('projects', p.id); toast('Projet supprimé') } catch (e) { toast(e.message, 'error') }
  }
  const reorder = async (next) => {
    try { await saveOrder('projects', next.map((p) => p.id)) } catch (e) { toast(e.message, 'error') }
  }

  return (
    <>
      <PageHeader title="Mes projets" intro="Seuls les projets publiés apparaissent sur le site. Glisse les lignes (ou utilise les flèches) pour changer leur ordre.">
        <Link to="/admin/projets/nouveau" className="btn-primary !py-2.5"><Plus className="h-4 w-4" /> Ajouter un projet</Link>
      </PageHeader>

      {usingSeed && (
        <div className="mb-6 rounded-2xl bg-[#f1ddc6] p-5 text-sm text-[#6b4217]">
          <p><strong>Tes 5 projets sont intégrés au code du site</strong> et s'affichent déjà en ligne. Pour pouvoir les modifier, réorganiser ou les masquer ici, importe-les dans ta base.</p>
          <button onClick={() => importSeed().then(() => toast('Projets importés')).catch((e) => toast(e.message, 'error'))} className="btn-primary mt-4 !py-2.5">Importer mes projets dans la base</button>
        </div>
      )}
      {projects.length === 0 ? (
        <Card className="py-20 text-center">
          <p className="font-display text-3xl italic text-taupe-deep">Aucun projet pour l'instant</p>
          <p className="mx-auto mt-2 max-w-md text-sm text-taupe-deep">Crée ton premier projet : tu peux l'enregistrer en brouillon, puis le publier quand il est prêt.</p>
          <button onClick={() => navigate('/admin/projets/nouveau')} className="btn-primary mt-7"><Plus className="h-4 w-4" /> Ajouter un projet</button>
        </Card>
      ) : (
        <SortableList
          items={projects}
          onReorder={reorder}
          className="space-y-3"
          renderItem={(p, _i, { handle, arrows }) => (
            <div className="flex items-center gap-3 rounded-2xl border border-cocoa/10 bg-cream p-3 shadow-card sm:gap-4 sm:p-4">
              <div className="hidden items-center gap-1 sm:flex">{handle}{arrows}</div>
              <div className="h-16 w-20 shrink-0 overflow-hidden rounded-xl bg-sand">
                {p.cover_url ? <img src={p.cover_url} alt="" className="h-full w-full object-cover" /> : <Placeholder label="" icon={false} />}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-display text-xl leading-tight">{p.title}</p>
                <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-taupe-deep">
                  {p.category && <span>{p.category}</span>}
                  <Badge tone={p.status === 'published' ? 'ok' : 'warn'}>{p.status === 'published' ? 'Publié' : 'Brouillon'}</Badge>
                </div>
              </div>
              <div className="flex shrink-0 items-center">
                <span className="sm:hidden">{arrows}</span>
                {p.status === 'published' && <Link to={`/projets/${p.slug}`} target="_blank" aria-label="Voir sur le site" title="Voir sur le site" className="rounded-full p-2.5 hover:bg-sand"><ExternalLink className="h-4 w-4" /></Link>}
                <IconBtn label={p.status === 'published' ? 'Masquer (repasser en brouillon)' : 'Publier'} onClick={() => toggle(p)}>{p.status === 'published' ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</IconBtn>
                <Link to={`/admin/projets/${p.id}`} aria-label="Modifier" title="Modifier" className="rounded-full p-2.5 hover:bg-sand"><Pencil className="h-4 w-4" /></Link>
                <IconBtn label="Supprimer" danger onClick={() => del(p)}><Trash2 className="h-4 w-4" /></IconBtn>
              </div>
            </div>
          )}
        />
      )}
    </>
  )
}
