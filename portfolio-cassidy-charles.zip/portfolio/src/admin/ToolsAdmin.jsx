import { useState } from 'react'
import { useData } from '../context/DataContext'
import { Card, PageHeader, useToast } from './ui'
import { TOOLS, TOOL_GROUPS } from '../lib/tools'

export default function ToolsAdmin() {
  const { content, saveContent } = useData()
  const toast = useToast()
  const [hidden, setHidden] = useState(content.tools.hidden || [])
  const [title, setTitle] = useState(content.tools.title)
  const [intro, setIntro] = useState(content.tools.intro)
  const [saving, setSaving] = useState(false)

  const toggle = (k) => setHidden((h) => (h.includes(k) ? h.filter((x) => x !== k) : [...h, k]))
  const save = async () => {
    setSaving(true)
    try { await saveContent({ ...content, tools: { ...content.tools, title, intro, hidden } }); toast('Logiciels enregistrés') } catch (e) { toast(e.message, 'error') }
    setSaving(false)
  }

  return (
    <>
      <PageHeader title="Logiciels" intro="Coche uniquement les logiciels que tu utilises vraiment : les autres disparaissent du site.">
        <button onClick={save} disabled={saving} className="btn-primary !py-2.5">Enregistrer</button>
      </PageHeader>
      <Card className="mb-6 space-y-4">
        <div><label htmlFor="t-title" className="label">Titre de la section</label><input id="t-title" className="input" value={title} onChange={(e) => setTitle(e.target.value)} /></div>
        <div><label htmlFor="t-intro" className="label">Texte d'introduction</label><textarea id="t-intro" rows={2} className="input" value={intro} onChange={(e) => setIntro(e.target.value)} /></div>
      </Card>
      <div className="grid gap-5 md:grid-cols-2">
        {TOOL_GROUPS.map((g) => (
          <Card key={g.key} className="!p-5">
            <h2 className="mb-3 text-2xl">{g.title}</h2>
            <ul className="space-y-1">
              {TOOLS.filter((t) => t.group === g.key).map((t) => (
                <li key={t.key}>
                  <label className="flex cursor-pointer items-center gap-3 rounded-xl px-2 py-2 hover:bg-sand">
                    <input type="checkbox" className="h-4 w-4 accent-[#49372F]" checked={!hidden.includes(t.key)} onChange={() => toggle(t.key)} />
                    {t.logo ? <img src={t.logo} alt="" className="h-6 w-6 object-contain" /> : <span className="flex h-6 w-6 items-center justify-center rounded-md bg-cocoa font-display text-sm italic text-cream">{t.mono}</span>}
                    <span className="text-sm">{t.name}</span>
                  </label>
                </li>
              ))}
            </ul>
          </Card>
        ))}
      </div>
    </>
  )
}
