import { useState } from 'react'
import { NavLink, Navigate, Route, Routes } from 'react-router-dom'
import { Award, ExternalLink, FileText, FolderKanban, Image, LayoutDashboard, LogOut, MapPin, Menu, Palette, Wrench, Search, User, X } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { useData } from '../context/DataContext'
import { ToastProvider } from './ui'
import Login from './Login'
import Dashboard from './Dashboard'
import MediaLibrary from './MediaLibrary'
import ProjectsAdmin from './ProjectsAdmin'
import ProjectForm from './ProjectForm'
import SkillsAdmin from './SkillsAdmin'
import ToolsAdmin from './ToolsAdmin'
import DocsAdmin from './DocsAdmin'
import { PresentationAdmin, SeekingAdmin, ContactAdmin } from './ContentPages'
import { useMeta } from '../lib/useMeta'
import { cn } from '../lib/utils'

const NAV = [
  { to: '', end: true, icon: LayoutDashboard, label: 'Tableau de bord' },
  { to: 'medias', icon: Image, label: 'Photos & médias' },
  { to: 'projets', icon: FolderKanban, label: 'Mes projets' },
  { to: 'competences', icon: Palette, label: 'Compétences' },
  { to: 'logiciels', icon: Wrench, label: 'Logiciels' },
  { to: 'presentation', icon: User, label: 'Présentation' },
  { to: 'recherche', icon: Search, label: 'Recherche de stage' },
  { to: 'documents', icon: FileText, label: 'CV & lettre' },
  { to: 'coordonnees', icon: MapPin, label: 'Coordonnées' },
]

function Shell() {
  const { signOut, demo } = useAuth()
  const { loading, error } = useData()
  const [open, setOpen] = useState(false)
  const link = ({ isActive }) => cn('flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm transition', isActive ? 'bg-cocoa text-cream' : 'text-cocoa hover:bg-sand')

  const nav = (
    <nav aria-label="Administration" className="flex flex-col gap-1">
      {NAV.map(({ to, end, icon: Icon, label }) => (
        <NavLink key={to} to={`/admin/${to}`.replace(/\/$/, '') || '/admin'} end={end} onClick={() => setOpen(false)} className={link}>
          <Icon className="h-4 w-4" strokeWidth={1.6} /> {label}
        </NavLink>
      ))}
    </nav>
  )

  return (
    <div className="min-h-screen bg-cream lg:pl-64">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-cocoa/10 bg-cream p-5 lg:flex">
        <p className="mb-8 px-2 font-display text-2xl">Cassidy <span className="italic">Charles</span><span className="block font-sans text-[0.65rem] uppercase tracking-[0.22em] text-taupe-deep">Administration</span></p>
        {nav}
        <div className="mt-auto space-y-1 border-t border-cocoa/10 pt-4">
          <a href="/" target="_blank" rel="noreferrer" className="flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm hover:bg-sand"><ExternalLink className="h-4 w-4" /> Voir le site</a>
          <button onClick={signOut} className="flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-sm hover:bg-sand"><LogOut className="h-4 w-4" /> {demo ? 'Quitter la démo' : 'Se déconnecter'}</button>
        </div>
      </aside>

      <header className="sticky top-0 z-40 flex items-center justify-between border-b border-cocoa/10 bg-cream/95 px-4 py-3 backdrop-blur lg:hidden">
        <p className="font-display text-xl">Administration</p>
        <button onClick={() => setOpen((o) => !o)} aria-label="Menu" aria-expanded={open} className="rounded-full p-2">{open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}</button>
      </header>
      {open && (
        <div className="fixed inset-x-0 top-[57px] z-30 max-h-[calc(100vh-57px)] overflow-y-auto border-b border-cocoa/10 bg-cream p-4 shadow-soft lg:hidden">
          {nav}
          <div className="mt-3 flex gap-2 border-t border-cocoa/10 pt-3">
            <a href="/" target="_blank" rel="noreferrer" className="btn-ghost flex-1 !py-2 !text-[0.8rem]">Voir le site</a>
            <button onClick={signOut} className="btn-soft flex-1 !py-2 !text-[0.8rem]">{demo ? 'Quitter' : 'Déconnexion'}</button>
          </div>
        </div>
      )}

      <main className="mx-auto max-w-5xl px-5 py-8 sm:px-8 sm:py-12">
        {demo && <p className="mb-6 rounded-full bg-[#f1ddc6] px-4 py-2 text-center text-xs font-medium text-[#6b4217]">MODE DÉMO — rien n'est enregistré durablement</p>}
        {error && <p role="alert" className="mb-6 rounded-2xl bg-[#8a3a2e]/10 p-4 text-sm text-[#8a3a2e]">Erreur de chargement : {error}</p>}
        {loading ? <p className="text-taupe-deep">Chargement…</p> : (
          <Routes>
            <Route index element={<Dashboard />} />
            <Route path="medias" element={<MediaLibrary />} />
            <Route path="projets" element={<ProjectsAdmin />} />
            <Route path="projets/nouveau" element={<ProjectForm />} />
            <Route path="projets/:id" element={<ProjectForm />} />
            <Route path="competences" element={<SkillsAdmin />} />
            <Route path="logiciels" element={<ToolsAdmin />} />
            <Route path="presentation" element={<PresentationAdmin />} />
            <Route path="recherche" element={<SeekingAdmin />} />
            <Route path="documents" element={<DocsAdmin />} />
            <Route path="coordonnees" element={<ContactAdmin />} />
            <Route path="*" element={<Navigate to="/admin" replace />} />
          </Routes>
        )}
      </main>
    </div>
  )
}

export default function AdminApp() {
  const { user, ready } = useAuth()
  useMeta('Administration — Cassidy Charles')
  // l'admin ne doit pas être indexée
  if (typeof document !== 'undefined') {
    let m = document.head.querySelector('meta[name="robots"]')
    if (!m) { m = document.createElement('meta'); m.name = 'robots'; document.head.appendChild(m) }
    m.content = 'noindex, nofollow'
  }
  if (!ready) return <div className="p-10 text-taupe-deep">Chargement…</div>
  if (!user) return <Login />
  return (
    <ToastProvider>
      <Shell />
    </ToastProvider>
  )
}
