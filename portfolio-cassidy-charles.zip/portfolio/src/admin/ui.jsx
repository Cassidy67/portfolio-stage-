import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowDown, ArrowUp, Check, GripVertical, X } from 'lucide-react'
import { cn } from '../lib/utils'

/* ---------- Toasts ---------- */
const ToastCtx = createContext(() => {})
export const useToast = () => useContext(ToastCtx)

export function ToastProvider({ children }) {
  const [items, setItems] = useState([])
  const toast = useCallback((message, type = 'ok') => {
    const id = Math.random()
    setItems((x) => [...x, { id, message, type }])
    setTimeout(() => setItems((x) => x.filter((i) => i.id !== id)), type === 'error' ? 6000 : 3000)
  }, [])
  return (
    <ToastCtx.Provider value={toast}>
      {children}
      <div aria-live="polite" className="pointer-events-none fixed bottom-5 left-1/2 z-[200] flex -translate-x-1/2 flex-col items-center gap-2">
        <AnimatePresence>
          {items.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className={cn('pointer-events-auto flex max-w-[90vw] items-center gap-2 rounded-full px-5 py-3 text-sm shadow-soft', t.type === 'error' ? 'bg-[#8a3a2e] text-white' : 'bg-cocoa text-cream')}
            >
              {t.type !== 'error' && <Check className="h-4 w-4" />} {t.message}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </ToastCtx.Provider>
  )
}

/* ---------- Mise en page ---------- */
export function PageHeader({ title, intro, children }) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
      <div className="max-w-2xl">
        <h1 className="text-4xl sm:text-5xl">{title}</h1>
        {intro && <p className="mt-2 text-taupe-deep">{intro}</p>}
      </div>
      <div className="flex flex-wrap gap-3">{children}</div>
    </div>
  )
}

export const Card = ({ className = '', children }) => (
  <div className={cn('rounded-3xl border border-cocoa/10 bg-cream p-6 shadow-card sm:p-8', className)}>{children}</div>
)

export function Field({ label, hint, htmlFor, children }) {
  return (
    <div>
      <label htmlFor={htmlFor} className="label">{label}</label>
      {children}
      {hint && <p className="mt-1.5 text-xs text-taupe-deep">{hint}</p>}
    </div>
  )
}

let n = 0
export function Input({ label, hint, value, onChange, textarea, rows = 4, className, ...rest }) {
  const id = useRef('f' + ++n).current
  const Tag = textarea ? 'textarea' : 'input'
  return (
    <Field label={label} hint={hint} htmlFor={id}>
      <Tag id={id} value={value ?? ''} onChange={(e) => onChange(e.target.value)} rows={textarea ? rows : undefined} className={cn('input', textarea && 'resize-y', className)} {...rest} />
    </Field>
  )
}

export function Select({ label, value, onChange, options, hint }) {
  const id = useRef('s' + ++n).current
  return (
    <Field label={label} hint={hint} htmlFor={id}>
      <select id={id} value={value ?? ''} onChange={(e) => onChange(e.target.value)} className="input">
        <option value="">— Choisir —</option>
        {options.map((o) => <option key={o}>{o}</option>)}
      </select>
    </Field>
  )
}

export function TagInput({ label, value = [], onChange, hint }) {
  const [draft, setDraft] = useState('')
  const id = useRef('t' + ++n).current
  const add = () => {
    const parts = draft.split(',').map((s) => s.trim()).filter(Boolean)
    if (parts.length) onChange([...new Set([...value, ...parts])])
    setDraft('')
  }
  return (
    <Field label={label} hint={hint} htmlFor={id}>
      <div className="input flex flex-wrap items-center gap-2 !py-2">
        {value.map((t) => (
          <span key={t} className="chip !bg-sand">
            {t}
            <button type="button" onClick={() => onChange(value.filter((x) => x !== t))} aria-label={`Retirer ${t}`} className="ml-1.5"><X className="h-3 w-3" /></button>
          </span>
        ))}
        <input
          id={id}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); add() } }}
          onBlur={add}
          placeholder={value.length ? '' : 'Figma, Canva… (Entrée pour ajouter)'}
          className="min-w-[8rem] flex-1 bg-transparent py-1 text-sm outline-none"
        />
      </div>
    </Field>
  )
}

export function Modal({ open, onClose, title, children, wide }) {
  useEffect(() => {
    if (!open) return
    const k = (e) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', k)
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.removeEventListener('keydown', k); document.body.style.overflow = prev }
  }, [open, onClose])
  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-[120] flex items-end justify-center bg-cocoa/60 p-0 backdrop-blur-sm sm:items-center sm:p-6" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={onClose}>
          <motion.div
            role="dialog" aria-modal="true" aria-label={title}
            initial={{ y: 30, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 30, opacity: 0 }}
            onMouseDown={(e) => e.stopPropagation()}
            className={cn('flex max-h-[92vh] w-full flex-col overflow-hidden rounded-t-3xl bg-cream shadow-2xl sm:rounded-3xl', wide ? 'max-w-5xl' : 'max-w-xl')}
          >
            <div className="flex items-center justify-between border-b border-cocoa/10 px-6 py-4">
              <h2 className="text-2xl">{title}</h2>
              <button onClick={onClose} aria-label="Fermer" className="rounded-full p-2 hover:bg-sand"><X className="h-5 w-5" /></button>
            </div>
            <div className="overflow-y-auto p-6">{children}</div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

/* ---------- Liste réorganisable : glisser-déposer + flèches (mobile / clavier) ---------- */
export function SortableList({ items, onReorder, renderItem, getKey = (i) => i.id, className }) {
  const [drag, setDrag] = useState(null)
  const [over, setOver] = useState(null)
  const move = (from, to) => {
    if (to < 0 || to >= items.length || from === to) return
    const next = [...items]
    const [it] = next.splice(from, 1)
    next.splice(to, 0, it)
    onReorder(next)
  }
  return (
    <ul className={className}>
      {items.map((it, i) => (
        <li
          key={getKey(it)}
          draggable
          onDragStart={(e) => { setDrag(i); e.dataTransfer.effectAllowed = 'move' }}
          onDragOver={(e) => { e.preventDefault(); setOver(i) }}
          onDragEnd={() => { setDrag(null); setOver(null) }}
          onDrop={(e) => { e.preventDefault(); move(drag, i); setDrag(null); setOver(null) }}
          className={cn('transition', drag === i && 'opacity-40', over === i && drag !== null && drag !== i && 'ring-2 ring-cocoa/40 rounded-2xl')}
        >
          {renderItem(it, i, {
            handle: <span className="cursor-grab text-taupe active:cursor-grabbing" aria-hidden title="Glisser pour réorganiser"><GripVertical className="h-5 w-5" /></span>,
            arrows: (
              <span className="flex flex-col">
                <button type="button" onClick={() => move(i, i - 1)} disabled={i === 0} aria-label="Monter" className="rounded p-0.5 hover:bg-sand disabled:opacity-25"><ArrowUp className="h-3.5 w-3.5" /></button>
                <button type="button" onClick={() => move(i, i + 1)} disabled={i === items.length - 1} aria-label="Descendre" className="rounded p-0.5 hover:bg-sand disabled:opacity-25"><ArrowDown className="h-3.5 w-3.5" /></button>
              </span>
            ),
          })}
        </li>
      ))}
    </ul>
  )
}

export const IconBtn = ({ label, children, danger, className, ...rest }) => (
  <button type="button" aria-label={label} title={label} className={cn('rounded-full p-2.5 transition', danger ? 'text-[#8a3a2e] hover:bg-[#8a3a2e]/10' : 'text-cocoa hover:bg-sand', className)} {...rest}>
    {children}
  </button>
)

export function Badge({ tone = 'neutral', children }) {
  return (
    <span className={cn('inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium', tone === 'ok' ? 'bg-[#dfe8d5] text-[#3f5a2c]' : tone === 'warn' ? 'bg-[#f1ddc6] text-[#7a4a1c]' : 'bg-sand text-taupe-deep')}>
      {children}
    </span>
  )
}
