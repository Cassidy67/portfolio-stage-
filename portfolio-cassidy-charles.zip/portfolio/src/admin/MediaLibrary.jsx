import { useMemo, useRef, useState } from 'react'
import { Crop, FileText, Loader2, Pencil, Replace, Trash2, Upload } from 'lucide-react'
import { useData } from '../context/DataContext'
import { Badge, Card, IconBtn, Modal, PageHeader, Input, useToast } from './ui'
import Cropper from './Cropper'
import { ACCEPT_IMG, uploadImages } from './upload'
import { optimizeImage } from '../lib/images'
import { fmtSize } from '../lib/utils'

export default function MediaLibrary() {
  const { media, uploadMedia, updateMedia, deleteMedia, replaceMedia, usageOf } = useData()
  const toast = useToast()
  const [tab, setTab] = useState('image')
  const [busy, setBusy] = useState(false)
  const [edit, setEdit] = useState(null)
  const [crop, setCrop] = useState(null)
  const [over, setOver] = useState(false)
  const input = useRef(null)
  const replaceInput = useRef(null)
  const replaceTarget = useRef(null)

  const list = media.filter((m) => m.kind === tab)
  const unusedCount = useMemo(() => media.filter((m) => !usageOf(m.url).length).length, [media, usageOf])

  const upload = async (files) => {
    setBusy(true)
    const rows = await uploadImages(files, uploadMedia, toast)
    setBusy(false)
    if (rows.length) toast(`${rows.length} photo${rows.length > 1 ? 's ajoutées' : ' ajoutée'}`)
  }

  const remove = async (m) => {
    const used = usageOf(m.url)
    const msg = used.length ? `Cette image est utilisée (${used.join(', ')}). La supprimer la fera disparaître de ces endroits. Continuer ?` : `Supprimer « ${m.name} » ?`
    if (!confirm(msg)) return
    try { await deleteMedia(m); toast('Supprimé') } catch (e) { toast(e.message, 'error') }
  }

  const removeUnused = async () => {
    const unused = media.filter((m) => !usageOf(m.url).length)
    if (!unused.length || !confirm(`Supprimer ${unused.length} fichier(s) non utilisé(s) ?`)) return
    for (const m of unused) await deleteMedia(m)
    toast('Médias inutilisés supprimés')
  }

  const onReplace = async (file) => {
    const m = replaceTarget.current
    if (!file || !m) return
    try {
      const blob = m.kind === 'pdf' ? file : await optimizeImage(file)
      await replaceMedia(m.id, blob, m)
      toast('Fichier remplacé partout où il était utilisé')
    } catch (e) { toast(e.message, 'error') }
  }

  const saveEdit = async () => {
    try { await updateMedia(edit.id, { name: edit.name, alt: edit.alt }); setEdit(null); toast('Enregistré') } catch (e) { toast(e.message, 'error') }
  }

  return (
    <>
      <PageHeader title="Photos & médias" intro="Toutes tes images et tes PDF au même endroit. Une photo importée ici peut être réutilisée dans plusieurs sections.">
        {unusedCount > 0 && <button onClick={removeUnused} className="btn-ghost !py-2.5 !text-[0.8rem]">Supprimer les {unusedCount} inutilisés</button>}
        <button onClick={() => input.current.click()} disabled={busy} className="btn-primary !py-2.5">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} Ajouter des photos
        </button>
      </PageHeader>
      <input ref={input} type="file" accept={ACCEPT_IMG} multiple hidden onChange={(e) => { upload(e.target.files); e.target.value = '' }} />
      <input ref={replaceInput} type="file" accept={ACCEPT_IMG + ',application/pdf'} hidden onChange={(e) => { onReplace(e.target.files?.[0]); e.target.value = '' }} />

      <div className="mb-6 flex gap-2" role="tablist">
        {[['image', 'Photos'], ['pdf', 'Documents PDF']].map(([k, l]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={`rounded-full border px-5 py-2 text-sm ${tab === k ? 'border-cocoa bg-cocoa text-cream' : 'border-cocoa/25'}`}>
            {l} <span className="opacity-60">({media.filter((m) => m.kind === k).length})</span>
          </button>
        ))}
      </div>

      <div
        onDragOver={(e) => { e.preventDefault(); setOver(true) }} onDragLeave={() => setOver(false)}
        onDrop={(e) => { e.preventDefault(); setOver(false); tab === 'image' && upload(e.dataTransfer.files) }}
        className={`rounded-3xl transition ${over ? 'bg-sand ring-2 ring-dashed ring-cocoa/40' : ''}`}
      >
        {list.length === 0 ? (
          <Card className="py-20 text-center">
            <p className="font-display text-3xl italic text-taupe-deep">{tab === 'image' ? 'Aucune photo pour le moment' : 'Aucun document pour le moment'}</p>
            <p className="mt-2 text-sm text-taupe-deep">{tab === 'image' ? 'Glisse tes photos ici ou clique sur « Ajouter des photos ». Elles sont automatiquement optimisées pour le web.' : 'Les PDF (CV, lettre) s\'ajoutent depuis la rubrique CV & lettre.'}</p>
          </Card>
        ) : (
          <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {list.map((m) => {
              const used = usageOf(m.url)
              return (
                <li key={m.id} className="overflow-hidden rounded-2xl border border-cocoa/10 bg-cream shadow-card">
                  <div className="aspect-square bg-sand">
                    {m.kind === 'image' ? <img src={m.url} alt={m.alt || m.name} loading="lazy" className="h-full w-full object-cover" /> : (
                      <a href={m.url} target="_blank" rel="noreferrer" className="flex h-full flex-col items-center justify-center gap-2 text-taupe-deep"><FileText className="h-10 w-10" strokeWidth={1.2} /> Ouvrir le PDF</a>
                    )}
                  </div>
                  <div className="p-3">
                    <p className="truncate text-sm font-medium" title={m.name}>{m.name}</p>
                    <p className="mt-0.5 text-xs text-taupe-deep">{fmtSize(m.size)}</p>
                    <div className="mt-2 flex flex-wrap gap-1" title={used.join('\n')}>
                      {used.length ? <Badge tone="ok">Utilisée ×{used.length}</Badge> : <Badge>Non utilisée</Badge>}
                    </div>
                    <div className="mt-2 flex items-center justify-between">
                      <div className="flex">
                        <IconBtn label="Renommer / description" onClick={() => setEdit({ ...m })}><Pencil className="h-4 w-4" /></IconBtn>
                        {m.kind === 'image' && !/svg|gif/.test(m.url) && <IconBtn label="Recadrer" onClick={() => setCrop(m)}><Crop className="h-4 w-4" /></IconBtn>}
                        <IconBtn label="Remplacer le fichier" onClick={() => { replaceTarget.current = m; replaceInput.current.click() }}><Replace className="h-4 w-4" /></IconBtn>
                      </div>
                      <IconBtn label="Supprimer" danger onClick={() => remove(m)}><Trash2 className="h-4 w-4" /></IconBtn>
                    </div>
                  </div>
                </li>
              )
            })}
          </ul>
        )}
      </div>

      <Modal open={!!edit} onClose={() => setEdit(null)} title="Renommer la photo">
        {edit && (
          <div className="space-y-5">
            <Input label="Nom du fichier" value={edit.name} onChange={(v) => setEdit({ ...edit, name: v })} />
            {edit.kind === 'image' && <Input label="Description de l'image" hint="Lue par les lecteurs d'écran et utile pour le référencement." value={edit.alt} onChange={(v) => setEdit({ ...edit, alt: v })} />}
            <div className="flex justify-end gap-3"><button onClick={() => setEdit(null)} className="btn-ghost !py-2.5">Annuler</button><button onClick={saveEdit} className="btn-primary !py-2.5">Enregistrer</button></div>
          </div>
        )}
      </Modal>

      {crop && (
        <Cropper
          source={crop.url}
          initialPreset="original"
          title="Recadrer — remplace la photo partout où elle est utilisée"
          onCancel={() => setCrop(null)}
          onDone={async (blob) => {
            const m = crop
            setCrop(null)
            try { await replaceMedia(m.id, blob, m); toast('Photo recadrée') } catch (e) { toast(e.message, 'error') }
          }}
        />
      )}
    </>
  )
}
