import { useEffect, useState } from 'react'
import { Loader2, Save } from 'lucide-react'
import { useData } from '../context/DataContext'
import { Card, Input, PageHeader, TagInput, useToast } from './ui'
import ImageField from './ImageField'

// Brouillon local d'une partie du contenu + bouton Enregistrer.
function useDraft() {
  const { content, saveContent, loading } = useData()
  const toast = useToast()
  const [d, setD] = useState(null)
  const [saving, setSaving] = useState(false)
  useEffect(() => { if (!loading && !d) setD(JSON.parse(JSON.stringify(content))) }, [loading, content, d])
  const set = (path, value) => setD((x) => {
    const n = JSON.parse(JSON.stringify(x))
    const keys = path.split('.')
    let o = n
    keys.slice(0, -1).forEach((k) => (o = o[k]))
    o[keys.at(-1)] = value
    return n
  })
  const save = async () => {
    setSaving(true)
    try { await saveContent({ ...content, ...d }); toast('Modifications enregistrées') } catch (e) { toast(e.message, 'error') }
    setSaving(false)
  }
  return { d, set, save, saving }
}

const SaveBar = ({ saving, save }) => (
  <div className="fixed inset-x-0 bottom-0 z-30 border-t border-cocoa/10 bg-cream/95 backdrop-blur lg:left-64">
    <div className="mx-auto flex max-w-5xl justify-end px-5 py-3.5">
      <button onClick={save} disabled={saving} className="btn-primary !py-2.5">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Enregistrer</button>
    </div>
  </div>
)

export function PresentationAdmin() {
  const { d, set, save, saving } = useDraft()
  if (!d) return null
  return (
    <>
      <PageHeader title="Présentation personnelle" intro="Textes et photos de l'accueil, et de la section « À propos »." />
      <div className="space-y-6 pb-28">
        <Card className="space-y-5">
          <h2 className="text-2xl">Accueil</h2>
          <div className="grid gap-5 sm:grid-cols-2">
            <Input label="Nom affiché" value={d.hero.name} onChange={(v) => set('hero.name', v)} />
            <Input label="Sous-titre" value={d.hero.subtitle} onChange={(v) => set('hero.subtitle', v)} />
          </div>
          <Input label="Phrase d'accroche" value={d.hero.tagline} onChange={(v) => set('hero.tagline', v)} />
          <Input label="Mention complémentaire" value={d.hero.status} onChange={(v) => set('hero.status', v)} />
          <ImageField label="Photo portrait (accueil)" preset="portrait" value={d.hero.portrait} alt={d.hero.portraitAlt} onChange={({ url, alt }) => { set('hero.portrait', url); set('hero.portraitAlt', alt) }} hint="Format portrait 4:5 recommandé." />
        </Card>

        <Card className="space-y-5">
          <h2 className="text-2xl">À propos de moi</h2>
          <Input label="Titre" value={d.about.title} onChange={(v) => set('about.title', v)} />
          <Input label="Biographie — premier paragraphe" textarea rows={4} value={d.about.paragraphs[0]} onChange={(v) => set('about.paragraphs', [v, d.about.paragraphs[1] || ''])} />
          <Input label="Biographie — second paragraphe" textarea rows={4} value={d.about.paragraphs[1]} onChange={(v) => set('about.paragraphs', [d.about.paragraphs[0] || '', v])} />
          <TagInput label="En quelques mots" hint="Qualités affichées sous ta biographie (Entrée pour ajouter)." value={d.about.qualities || []} onChange={(v) => set('about.qualities', v)} />
          <ImageField label="Photo personnelle (à propos)" preset="portrait" value={d.about.photo} alt={d.about.photoAlt} onChange={({ url, alt }) => { set('about.photo', url); set('about.photoAlt', alt) }} />
        </Card>

        <Card className="space-y-5">
          <h2 className="text-2xl">Mes projets</h2>
          <Input label="Texte d'introduction" textarea rows={3} value={d.projects.intro} onChange={(v) => set('projects.intro', v)} />
        </Card>

      </div>
      <SaveBar saving={saving} save={save} />
    </>
  )
}

export function SeekingAdmin() {
  const { d, set, save, saving } = useDraft()
  if (!d) return null
  const s = d.seeking
  return (
    <>
      <PageHeader title="Recherche de stage" intro="Les informations de la section « À la recherche d'une nouvelle expérience »." />
      <div className="space-y-6 pb-28">
        <Card className="space-y-5">
          <Input label="Titre" value={s.title} onChange={(v) => set('seeking.title', v)} />
          <Input label="Présentation" textarea rows={4} value={s.text} onChange={(v) => set('seeking.text', v)} />
          <div className="grid gap-5 sm:grid-cols-2">
            <Input label="Domaines" value={s.domains} onChange={(v) => set('seeking.domains', v)} />
            <Input label="Période" value={s.period} onChange={(v) => set('seeking.period', v)} />
            <Input label="Durée" value={s.duration} onChange={(v) => set('seeking.duration', v)} />
            <Input label="Localisation" value={s.location} onChange={(v) => set('seeking.location', v)} />
          </div>
        </Card>
      </div>
      <SaveBar saving={saving} save={save} />
    </>
  )
}

export function ContactAdmin() {
  const { d, set, save, saving } = useDraft()
  if (!d) return null
  const c = d.contact
  return (
    <>
      <PageHeader title="Coordonnées" intro="Tes informations de contact et celles des mentions légales." />
      <div className="space-y-6 pb-28">
        <Card className="space-y-5">
          <h2 className="text-2xl">Contact</h2>
          <Input label="Titre de la section" value={c.title} onChange={(v) => set('contact.title', v)} />
          <Input label="Texte" textarea rows={3} value={c.text} onChange={(v) => set('contact.text', v)} />
          <div className="grid gap-5 sm:grid-cols-2">
            <Input label="E-mail" type="email" value={c.email} onChange={(v) => set('contact.email', v)} />
            <Input label="Localisation" value={c.location} onChange={(v) => set('contact.location', v)} />
          </div>
          <Input label="Lien LinkedIn" type="url" value={c.linkedin} onChange={(v) => set('contact.linkedin', v)} />
        </Card>
        <Card className="space-y-5">
          <h2 className="text-2xl">Mentions légales — hébergeur</h2>
          <p className="text-sm text-taupe-deep">Obligatoire pour un site publié en France : nom et adresse du service qui héberge ton site (Netlify, Vercel, OVH…).</p>
          <Input label="Nom de l'hébergeur" value={d.legal.host} onChange={(v) => set('legal.host', v)} />
          <Input label="Adresse de l'hébergeur" value={d.legal.hostAddress} onChange={(v) => set('legal.hostAddress', v)} />
        </Card>
      </div>
      <SaveBar saving={saving} save={save} />
    </>
  )
}
