import { useRef, useState } from 'react'
import { Eye, FileText, Loader2, Trash2, Upload } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useData } from '../context/DataContext'
import { Card, PageHeader, useToast } from './ui'

function DocCard({ title, field, hint }) {
  const { content, saveContent, uploadMedia, media, deleteMedia } = useData()
  const toast = useToast()
  const [busy, setBusy] = useState(false)
  const input = useRef(null)
  const url = content.documents[field]
  const current = media.find((m) => m.url === url)

  const setUrl = (u) => saveContent({ ...content, documents: { ...content.documents, [field]: u } })

  const onFile = async (f) => {
    if (!f) return
    if (f.type !== 'application/pdf') return toast('Le document doit être un PDF.', 'error')
    if (f.size > 15 * 1024 * 1024) return toast('PDF trop lourd (max 15 Mo).', 'error')
    setBusy(true)
    try {
      const row = await uploadMedia(f, { name: f.name, kind: 'pdf' })
      await setUrl(row.url)
      if (current) await deleteMedia(current) // l'ancienne version est remplacée
      toast(url ? 'Document remplacé' : 'Document importé')
    } catch (e) { toast(e.message, 'error') }
    setBusy(false)
  }
  const remove = async () => {
    if (!confirm('Retirer ce document du site ? Le fichier sera supprimé.')) return
    try { await setUrl(''); if (current) await deleteMedia(current); toast('Document supprimé') } catch (e) { toast(e.message, 'error') }
  }

  return (
    <Card className="flex flex-col">
      <FileText className="h-7 w-7 text-taupe" strokeWidth={1.2} />
      <h2 className="mt-4 text-3xl">{title}</h2>
      <p className="mt-1 text-sm text-taupe-deep">{hint}</p>
      <div className="mt-6 flex-1 rounded-2xl border border-dashed border-cocoa/25 bg-sand/50 p-5 text-sm">
        {url ? (
          <p className="flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-[#5f8a3f]" /> En ligne{current ? ` — ${current.name}.pdf` : ''}</p>
        ) : <p className="text-taupe-deep">Aucun fichier importé : le bouton n'apparaît pas sur le site.</p>}
      </div>
      <div className="mt-5 flex flex-wrap gap-3">
        <button onClick={() => input.current.click()} disabled={busy} className="btn-primary !py-2.5 !text-[0.8rem]">{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} {url ? 'Remplacer' : 'Importer le PDF'}</button>
        {url && <a href={url} target="_blank" rel="noreferrer" className="btn-ghost !py-2.5 !text-[0.8rem]"><Eye className="h-4 w-4" /> Voir</a>}
        {url && <button onClick={remove} className="btn !py-2.5 !text-[0.8rem] text-[#8a3a2e] hover:bg-[#8a3a2e]/10"><Trash2 className="h-4 w-4" /> Supprimer</button>}
      </div>
      <input ref={input} type="file" accept="application/pdf" hidden onChange={(e) => { onFile(e.target.files?.[0]); e.target.value = '' }} />
    </Card>
  )
}

export default function DocsAdmin() {
  return (
    <>
      <PageHeader title="CV & lettre de motivation" intro="Importe tes PDF : ils s'ouvriront dans un nouvel onglet depuis la section « À propos ». Le CV peut aussi être téléchargé." />
      <div className="grid gap-6 md:grid-cols-2">
        <DocCard title="Mon CV" field="cv" hint="Fichier PDF — boutons « Voir mon CV » et « Télécharger mon CV »." />
        <DocCard title="Ma lettre de motivation" field="letter" hint="Fichier PDF — bouton « Voir ma lettre de motivation »." />
      </div>
    </>
  )
}
