import { Link } from 'react-router-dom'
import { Wrench, Award, FileText, FolderKanban, Image, MapPin, Palette, Plus, Search, User, Upload } from 'lucide-react'
import { useData } from '../context/DataContext'
import { useAuth } from '../context/AuthContext'
import { Card, PageHeader } from './ui'

export default function Dashboard() {
  const { adminProjects: projects, media, certs, skills, content } = useData()
  const { demo } = useAuth()
  const tiles = [
    { to: 'medias', icon: Image, title: 'Photos & médias', text: 'Importer, recadrer, renommer, réutiliser.', count: `${media.length} fichier${media.length > 1 ? 's' : ''}` },
    { to: 'projets', icon: FolderKanban, title: 'Mes projets', text: 'Créer, publier, masquer, réorganiser.', count: `${projects.filter((p) => p.status === 'published').length} publié(s) · ${projects.filter((p) => p.status !== 'published').length} brouillon(s)` },
    { to: 'competences', icon: Palette, title: 'Compétences', text: 'Ne garder que ce que tu maîtrises.', count: `${skills.filter((s) => s.visible).length} affichée(s)` },
    { to: 'logiciels', icon: Wrench, title: 'Logiciels', text: 'Les outils que tu utilises, avec leur logo.', count: `${22 - (content.tools.hidden || []).length} affichés` },
    { to: 'presentation', icon: User, title: 'Présentation personnelle', text: 'Accueil et biographie.', count: content.hero.name },
    { to: 'recherche', icon: Search, title: 'Recherche de stage', text: 'Période, durée, localisation.', count: content.seeking.period },
    { to: 'documents', icon: FileText, title: 'CV & lettre de motivation', text: 'Importer ou remplacer tes PDF.', count: `${content.documents.cv ? 'CV ✓' : 'CV —'} · ${content.documents.letter ? 'Lettre ✓' : 'Lettre —'}` },
    { to: 'coordonnees', icon: MapPin, title: 'Coordonnées', text: 'E-mail, LinkedIn, mentions légales.', count: content.contact.email },
  ]
  return (
    <>
      <PageHeader title="Bonjour Cassidy" intro="Voici ton espace pour faire vivre ton portfolio, sans toucher au code.">
        <Link to="projets/nouveau" className="btn-primary !py-2.5"><Plus className="h-4 w-4" /> Ajouter un projet</Link>
        <Link to="medias" className="btn-ghost !py-2.5"><Upload className="h-4 w-4" /> Importer des photos</Link>
      </PageHeader>

      {demo && (
        <p className="mb-8 rounded-2xl bg-[#f1ddc6] p-4 text-sm text-[#6b4217]"><strong>Mode démonstration :</strong> tu explores l'interface, mais rien n'est enregistré durablement. Configure Supabase (voir le README) pour activer la sauvegarde.</p>
      )}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {tiles.map(({ to, icon: Icon, title, text, count }) => (
          <Link key={to} to={to} className="group">
            <Card className="h-full !p-6 transition duration-300 group-hover:-translate-y-1 group-hover:shadow-soft">
              <span className="flex h-11 w-11 items-center justify-center rounded-full bg-blush/60 transition group-hover:bg-cocoa group-hover:text-cream"><Icon className="h-5 w-5" strokeWidth={1.4} /></span>
              <h2 className="mt-5 text-2xl leading-tight">{title}</h2>
              <p className="mt-1 text-sm text-taupe-deep">{text}</p>
              <p className="mt-4 truncate border-t border-cocoa/10 pt-3 text-xs font-medium text-cocoa">{count}</p>
            </Card>
          </Link>
        ))}
      </div>
    </>
  )
}
