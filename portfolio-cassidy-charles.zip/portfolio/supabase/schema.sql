-- =====================================================================
--  Portfolio de Cassidy Charles — schéma Supabase
--  À coller dans Supabase > SQL Editor > New query > Run (une seule fois)
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- 1. Qui est administrateur ?
--    ⚠️ Remplace l'adresse ci-dessous par l'e-mail avec lequel tu créeras
--    ton compte dans Supabase > Authentication > Users.
-- ---------------------------------------------------------------------
create or replace function public.is_admin()
returns boolean
language sql
stable
as $$
  select coalesce(auth.jwt() ->> 'email', '') = lower('cassidy.charles@icloud.com')
$$;

-- ---------------------------------------------------------------------
-- 2. Tables
-- ---------------------------------------------------------------------
create table if not exists public.site_content (
  id int primary key default 1 check (id = 1),
  content jsonb not null default '{}'::jsonb
);
insert into public.site_content (id, content) values (1, '{}'::jsonb) on conflict (id) do nothing;

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  category text,
  project_type text,
  short_description text,
  context text,
  objectives text,
  role text,
  process text,
  tools text[] not null default '{}',
  result text,
  learnings text,
  cover_url text,
  cover_alt text,
  gallery jsonb not null default '[]'::jsonb,
  status text not null default 'draft' check (status in ('draft', 'published')),
  position int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.skills (
  id uuid primary key default gen_random_uuid(),
  category text not null check (category in ('design', 'marketing', 'web')),
  label text not null,
  visible boolean not null default true,
  position int not null default 0
);

create table if not exists public.certifications (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  issuer text,
  obtained_on date,
  file_url text,
  file_type text check (file_type in ('image', 'pdf')),
  published boolean not null default true,
  position int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.media (
  id uuid primary key default gen_random_uuid(),
  path text not null,
  url text not null,
  name text,
  kind text not null default 'image' check (kind in ('image', 'pdf')),
  size bigint,
  alt text,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 3. Règles d'accès (RLS) : les visiteurs LISENT le contenu publié,
--    seule l'administratrice peut créer / modifier / supprimer.
-- ---------------------------------------------------------------------
alter table public.site_content enable row level security;
alter table public.projects enable row level security;
alter table public.skills enable row level security;
alter table public.certifications enable row level security;
alter table public.media enable row level security;

drop policy if exists "content_read" on public.site_content;
drop policy if exists "content_admin" on public.site_content;
create policy "content_read" on public.site_content for select using (true);
create policy "content_admin" on public.site_content for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "projects_read" on public.projects;
drop policy if exists "projects_admin" on public.projects;
create policy "projects_read" on public.projects for select using (status = 'published' or public.is_admin());
create policy "projects_admin" on public.projects for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "skills_read" on public.skills;
drop policy if exists "skills_admin" on public.skills;
create policy "skills_read" on public.skills for select using (visible or public.is_admin());
create policy "skills_admin" on public.skills for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "certs_read" on public.certifications;
drop policy if exists "certs_admin" on public.certifications;
create policy "certs_read" on public.certifications for select using (published or public.is_admin());
create policy "certs_admin" on public.certifications for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "media_admin" on public.media;
create policy "media_admin" on public.media for all using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------
-- 4. Stockage des images et PDF (bucket public en lecture)
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('media', 'media', true)
on conflict (id) do nothing;

drop policy if exists "media_files_read" on storage.objects;
drop policy if exists "media_files_insert" on storage.objects;
drop policy if exists "media_files_update" on storage.objects;
drop policy if exists "media_files_delete" on storage.objects;
create policy "media_files_read" on storage.objects for select using (bucket_id = 'media');
create policy "media_files_insert" on storage.objects for insert with check (bucket_id = 'media' and public.is_admin());
create policy "media_files_update" on storage.objects for update using (bucket_id = 'media' and public.is_admin());
create policy "media_files_delete" on storage.objects for delete using (bucket_id = 'media' and public.is_admin());

-- ---------------------------------------------------------------------
-- 5. Compétences de départ (modifiables / supprimables depuis l'admin)
-- ---------------------------------------------------------------------
insert into public.skills (category, label, position)
select * from (values
  ('design', 'Création de contenus visuels', 1), ('design', 'UI/UX Design', 2),
  ('marketing', 'Stratégie de communication', 1), ('marketing', 'Marketing digital', 2), ('marketing', 'SEO/SEA', 3),
  ('marketing', 'Gestion des réseaux sociaux', 4), ('marketing', 'Création de contenus digitaux', 5), ('marketing', 'Veille concurrentielle', 6),
  ('web', 'Conception de sites web', 1), ('web', 'Maquettage d''interfaces', 2)
) as s(category, label, position)
where not exists (select 1 from public.skills);
